// 节奏探针：确定性假时间，bot 全开，按境界统计推进耗时
const fs=require('fs');const path=require('path');
function el(){return{style:{setProperty(){}},classList:{add(){},remove(){},toggle(){},contains(){return false}},children:[],
  innerHTML:'',textContent:'',disabled:false,hidden:false,dataset:{},
  appendChild(c){this.children.push(c)},removeChild(){},insertBefore(a){this.children.unshift(a)},
  remove(){},closest(){return el()},querySelector(){return el()},querySelectorAll(){return[]},addEventListener(){},
  getBoundingClientRect(){return{left:0,top:0,width:100,height:30}}}}
const store={};
Object.defineProperty(globalThis,'localStorage',{value:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},configurable:true});
global.document={getElementById(){return el()},createElement(){return el()},addEventListener(){},body:{appendChild(){}},documentElement:el(),head:{appendChild(){}},querySelector(){return el()},querySelectorAll(){return[]}};
global.window={addEventListener(){}};
global.confirm=()=>true;global.prompt=()=>null;global.alert=()=>{};
global.btoa=s=>Buffer.from(s).toString('base64');global.atob=s=>Buffer.from(s,'base64').toString();
global.matchMedia=()=>({matches:true});
global.innerWidth=1280;global.innerHeight=720;
global.requestAnimationFrame=()=>0;
const ctxStub={clearRect(){},createRadialGradient(){return{addColorStop(){}}},beginPath(){},arc(){},fill(){}};
globalThis.addEventListener=()=>{};
document.getElementById=id=>{const e=el();if(id==='bg')e.getContext=()=>ctxStub;return e};
const order=['data.js','core.js','state.js','actions.js','battle.js','trib.js','meta.js','render.js','main.js'];
let code='';for(const f of order)code+=fs.readFileSync(path.join(__dirname,'js',f),'utf8')+'\n';
const sim=`
// 确定性假时间：每次 tick 前进 1 秒
let fakeNow=1000;
const realPN=performance.now;
performance.now=()=>fakeNow;
Date.now=()=>fakeNow+ (new Date()).getTime()-1000; // 保持 Date 大致可用

S=freshState();S.root='tiandao';S.life=1;
beginOpen=false; // 绕过开局界面（节奏探针直接定灵根）
let clicks=0,sec=0,shopUsed=false;const t0={};let cur='';
function key(){return GX.REALMS[S.realmIdx].name+S.layer}
t0[key()]=0;cur=key();
for(let i=0;i<400000&&!ended;i++){
  sec++;
  // 每秒点击 10 次（真人疾点水平）
  for(let j=0;j<10;j++){doCultivate({target:el()});clicks++}
  for(const b of GX.BLDS){const c=bldCost(b.id);if(S.spirit>=c)buyBld(b.id)}
  for(const k in GX.PILLS){if(S.pills[k]<3&&S.spirit>=pillCost(k))craftPill(k)}
  for(let q=GX.TREASURES.length;q>=1;q--){const sc=shardCost(q);if(S.bld.forge>=q&&S.shards[sc.key]>=sc.n){forgeTreasure(q);break}}
  for(const k of ['fan','ling','xuan','di'])if(S.eggs[k]>0)hatchEgg(k);
  if(S.pills.huichun>0&&S.life/lifeCap()<0.8)usePill('huichun');
  if(S.pills.yanshou>0)usePill('yanshou');
  if(S.pills.xuan>0)usePill('xuan');
  if(S.pills.juli>0)usePill('juli');
  if(breakInfo().ok){ if(S.med>0)S.med=0; doBreak(); }   // 能渡劫就先出定
  if(tribOpen&&tribOpts[0])tribOpts[0].act(); // 渡劫期：bot 选硬渡
  else if(S.med===0)startMed();                          // 否则闭关（等效挂机）
  if(!pending.herb)startHerb();
  if(!pending.roam&&S.life/lifeCap()>0.5)startRoam();
  if(secretOpen&&secretOpts.length)secretOpts[0].act(); // 秘境：选第一项推进
  else if(encounterOpen)closeEncounter();
  if(S.secretCd<=0&&Math.random()<0.02)openSecret(); // 偶尔探秘境
  if(!shopUsed&&S.daoFruit>=15){shopUsed=true;beginOpen=true;buyShop('provision');buyShop('dharma');applyShopPurchases();beginOpen=false;} // 模拟玩家花道果
  if(sec%100===0)console.log('t='+sec,'life='+S.life.toFixed(1)+'/'+lifeCap(),'med='+S.med.toFixed(0),'cult='+S.cult.toExponential(3),'ended='+ended);
  const k=key();
  if(k!==cur){
    const d=sec-t0[cur];
    console.log((cur).padEnd(7)+' '+String(d).padStart(5)+'s   click='+fmt(cultPerClick()).padStart(9)+'  zhen/s='+fmt(zhenRate()).padStart(9));
    cur=k;t0[cur]=sec;
  }
  fakeNow+=1000;
  last=fakeNow-1000;
  tick();
  if(encounterOpen)closeEncounter();
}
console.log('END realm='+key(),'sec='+sec,'clicks='+clicks,'life='+S.life.toFixed(0)+'/'+lifeCap());
process.exit(0);
`;
eval(code+sim);
