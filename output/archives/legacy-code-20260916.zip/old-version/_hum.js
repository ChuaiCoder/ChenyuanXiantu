// 真人档节奏：3 点击/秒、只买能买的建筑、不常闭关、不攒丹、会死
const fs=require('fs');const path=require('path');
function el(){return{style:{setProperty(){}},classList:{add(){},remove(){},toggle(){},contains(){return false}},children:[],innerHTML:'',textContent:'',disabled:false,hidden:false,dataset:{},appendChild(c){this.children.push(c)},removeChild(){},insertBefore(a){this.children.unshift(a)},remove(){},closest(){return el()},querySelector(){return el()},querySelectorAll(){return[]},addEventListener(){},getBoundingClientRect(){return{left:0,top:0,width:100,height:30}}}}
const store={};
Object.defineProperty(globalThis,'localStorage',{value:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},configurable:true});
global.document={getElementById(){return el()},createElement(){return el()},addEventListener(){},body:{appendChild(){}},documentElement:el(),head:{appendChild(){}},querySelector(){return el()},querySelectorAll(){return[]}};
global.window={addEventListener(){}};global.confirm=()=>true;global.prompt=()=>null;global.alert=()=>{};
global.btoa=s=>Buffer.from(s).toString('base64');global.atob=s=>Buffer.from(s,'base64').toString();
global.matchMedia=()=>({matches:true});global.innerWidth=1280;global.innerHeight=720;global.requestAnimationFrame=()=>0;
const ctxStub={clearRect(){},createRadialGradient(){return{addColorStop(){}}},beginPath(){},arc(){},fill(){}};
globalThis.addEventListener=()=>{};
document.getElementById=id=>{const e=el();if(id==='bg')e.getContext=()=>ctxStub;return e};
const order=['data.js','core.js','state.js','actions.js','battle.js','trib.js','meta.js','render.js','main.js'];
let code='';for(const f of order)code+=fs.readFileSync(path.join(__dirname,'js',f),'utf8')+'\n';
eval(code+`
let fakeNow=1000;const realPN=performance.now;performance.now=()=>fakeNow;
function run(rootName,clicksPerSec,label){
  beginOpen=false; // 绕过开局界面（节奏探针直接定灵根）
  S=freshState();S.root=rootName;S.life=1;
  let sec=0;const milestones={};
  const want=['筑基','金丹','元婴','化神','炼虚','合体','大乘','渡劫'];
  let got=new Set(),shopUsed=false;
  for(let i=0;i<300000&&!ended;i++){
    sec++;
    for(let j=0;j<clicksPerSec;j++)doCultivate({target:el()});
    for(const b of GX.BLDS){const c=bldCost(b.id);if(S.spirit>=c)buyBld(b.id)}
    {const sc=shardCost(1);if(S.shards[sc.key]>=sc.n&&S.bld.forge>=1)forgeTreasure(1)}
    if(S.pills.huichun>0&&S.life/lifeCap()<0.6)usePill('huichun');   // 只快死才救
    if(S.pills.juli>0)usePill('juli');
    if(!pending.herb&&Math.random()<0.3)startHerb();
    if(breakInfo().ok&&S.med===0)doBreak();
    if(tribOpen&&tribOpts[0])tribOpts[0].act(); // 渡劫期：bot 选硬渡
    if(secretOpen&&secretOpts.length)secretOpts[0].act(); // 秘境：选第一项推进
    else if(encounterOpen)closeEncounter();
    if(S.secretCd<=0&&Math.random()<0.02)openSecret(); // 偶尔探秘境
    if(!shopUsed&&S.daoFruit>=15){shopUsed=true;beginOpen=true;buyShop('provision');buyShop('dharma');applyShopPurchases();beginOpen=false;} // 模拟玩家花道果
    for(const w of want){
      if(!got.has(w)&&S.realmIdx>=GX.REALMS.findIndex(r=>r.name===w)){got.add(w);milestones[w]=sec}
    }
    fakeNow+=1000;last=fakeNow-1000;tick();
    if(encounterOpen)closeEncounter();
  }
  const d=m=>m==null?'—':Math.round(m/60)+'分'+String(m%60).padStart(2,'0')+'秒';
  console.log('['+label+'] 筑基'+d(milestones['筑基'])+' 金丹'+d(milestones['金丹'])+' 元婴'+d(milestones['元婴'])+' 化神'+d(milestones['化神'])+' 炼虚'+d(milestones['炼虚'])+' 合体'+d(milestones['合体'])+' 大乘'+d(milestones['大乘'])+' 渡劫'+d(milestones['渡劫'])+' 终'+d(sec)+'(ended='+ended+')');
}
function reset(){ended=false;S=freshState()}
reset();run('jin',3,'3点击/秒·金根·不优化');
const r1={realm:S.realmIdx,layer:S.layer,life:S.life.toFixed(0),cap:lifeCap()};
reset();run('lei',8,'8点击/秒·雷根·不优化');
const r2={realm:S.realmIdx,layer:S.layer,life:S.life.toFixed(0),cap:lifeCap()};
console.log('run1终局: realm='+r1.realm+' L'+r1.layer+' life='+r1.life+'/'+r1.cap+' (life<cap=>飞升)');
console.log('run2终局: realm='+r2.realm+' L'+r2.layer+' life='+r2.life+'/'+r2.cap);
process.exit(0);
`);
