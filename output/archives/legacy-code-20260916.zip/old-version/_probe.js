// 优化探针：量化 后期灵石溢出 / 寿元压力 / 道果终局储备
const fs=require('fs');const path=require('path');
function el(){return{style:{setProperty(){}},classList:{add(){},remove(){},toggle(){},contains(){return false}},children:[],
  innerHTML:'',textContent:'',disabled:false,hidden:false,dataset:{},
  appendChild(c){this.children.push(c)},removeChild(){},insertBefore(a){this.children.unshift(a)},
  remove(){},closest(){return el()},querySelector(){return el()},querySelectorAll(){return[]},addEventListener(){},
  getBoundingClientRect(){return{left:0,top:0,width:100,height:30}}}}
const store={};
Object.defineProperty(globalThis,'localStorage',{value:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},configurable:true});
global.document={getElementById(){return el()},createElement(){return el()},addEventListener(){},body:{appendChild(){}},documentElement:el(),head:{appendChild(){}},querySelector(){return el()},querySelectorAll(){return[]}};
global.window={addEventListener(){}};global.confirm=()=>true;global.prompt=()=>null;global.alert=()=>{};
global.btoa=s=>Buffer.from(s).toString('base64');global.atob=s=>Buffer.from(s,'base64').toString();
global.matchMedia=()=>({matches:true});global.innerWidth=1280;global.innerHeight=720;global.requestAnimationFrame=()=>0;
const ctxStub={clearRect(){},createRadialGradient(){return{addColorStop(){}}},beginPath(){},arc(){},fill(){}};
globalThis.addEventListener=()=>{};
document.getElementById=id=>{const e=el();if(id==='bg')e.getContext=()=>ctxStub;return e};
const order=['data.js','core.js','state.js','actions.js','battle.js','trib.js','meta.js','render.js','main.js'];
let code='';for(const f of order)code+=fs.readFileSync(path.join(__dirname,'js',f),'utf8')+'\n';

const sim=[
'let fakeNow=1000; performance.now=()=>fakeNow;',
'function run(label,root,useFruitTrib){',
'  S=freshState();S.root=root;S.life=1;beginOpen=false;ended=false;',
'  let sec=0,spiritEnd=0,minLifeRatio=1,fruitAtFinalTrib=null;',
'  let huichunUse=0,yanshouUse=0,dujieUse=0,eggHatch=0;',
'  const uPill=(k)=>{',
'    if(S.pills[k]<=0)return;',
'    S.pills[k]--;',
'    if(k==="huichun"){huichunUse++;S.life+=5;}',
'    else if(k==="yanshou"){yanshouUse++;S.lifeBonus=(S.lifeBonus||0)+20;}',
'    else if(k==="juli")S.cult+=Math.ceil(layerNeed()*0.15);',
'    else if(k==="dujie")dujieUse++;',
'  };',
'  for(let i=0;i<400000&&!ended;i++){',
'    sec++;',
'    for(let j=0;j<10;j++)doCultivate({target:el()});',
'    for(const b of GX.BLDS){const c=bldCost(b.id);if(S.spirit>=c)buyBld(b.id)}',
'    for(const k in GX.PILLS){if(S.pills[k]<3&&S.spirit>=pillCost(k))craftPill(k)}',
'    {const sc=shardCost(1);if(S.shards[sc.key]>=sc.n&&S.bld.forge>=1)forgeTreasure(1)}',
'    for(const k of ["fan","ling","xuan","di"])if(S.eggs[k]>0){hatchEgg(k);eggHatch++}',
'    if(S.pills.yanshou>0)uPill("yanshou");',
'    if(S.pills.huichun>0&&S.life/lifeCap()<0.8)uPill("huichun");',
'    if(S.pills.juli>0)uPill("juli");',
'    if(S.pills.xuan>0&&breakInfo().ok)uPill("xuan");',
'    if(breakInfo().ok){if(S.med>0)S.med=0;',
'      if(S.realmIdx===8&&S.layer===8&&fruitAtFinalTrib===null)fruitAtFinalTrib=S.daoFruit;',
'      doBreak();}',
'    if(tribOpen&&tribOpts[0]){',
'      const o=(useFruitTrib&&S.daoFruit>=10&&tribOpts[1]&&!tribOpts[1].disabled)?tribOpts[1]:tribOpts[0];',
'      o.act();',
'    }',
'    if(encounterOpen)closeEncounter();',
'    minLifeRatio=Math.min(minLifeRatio,S.life/lifeCap());',
'    last=fakeNow-1000;tick();',
'    fakeNow+=1000;',
'  }',
'  spiritEnd=S.spirit;',
'  console.log("["+label+"]",',
'    "sec="+sec,"realm="+GX.REALMS[S.realmIdx].name+S.layer,"ended="+ended,',
'    "spiritEnd="+Math.round(spiritEnd),"minLifeRatio="+minLifeRatio.toFixed(3),',
'    "huichunUse="+huichunUse,"yanshouUse="+yanshouUse,"eggHatch="+eggHatch,',
'    "fruitAtFinalTrib="+(fruitAtFinalTrib==null?"?":fruitAtFinalTrib),"fruitEnd="+S.daoFruit);',
'}',
'run("10click/s-lei-finalTribUsesFruit","lei",true);',
'run("10click/s-jin-finalTribHard","jin",false);',
'process.exit(0);',
].join('\n');

eval(code+sim);
