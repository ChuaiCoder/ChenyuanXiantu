"use strict";
/* ============ 洞府行动：修炼 / 掉落 / 丹药 / 建筑 / 炼器 / 灵兽 / 闭关 ============
   只读 state.js 的公式，改 S，触发 render()。秘境（未来）也落此文件。 */

/* ---- 修炼 & 机缘掉落 ---- */
function doCultivate(ev){
  if(S.med>0)return; // 闭关入定中，心不外驰
  const v=cultPerClick();
  S.cult+=v;
  S.clicks++;
  floatTxt(ev.target.closest("button"),"+"+fmt(v));
  rollDrops();
  render();
}
function rollDrops(){
  const msgs=[];
  if(Math.random()<dropChance("spirit")){
    let n=Math.ceil(20*(S.realmIdx+1));
    if(S.root==="tiandao")n*=2;
    S.spirit+=n;
    msgs.push(`💠 灵气汇聚，灵石 +${fmt(n)}`);
  }
  if(Math.random()<dropChance("shard")){
    // 残片品级阶梯：境界越高掉越高级残片（仙界可掉地品→仙品法宝）
    const r=Math.random();
    const key=r<0.50?"fan":r<0.80?"ling":r<0.95?"xuan":"di";
    S.shards[key]++;
    const nm={fan:"凡品",ling:"灵品",xuan:"玄品",di:"地品"}[key];
    msgs.push(`🔨 拾得${nm}法宝残片×1`);
  }
  if(Math.random()<dropChance("egg")){
    const r=Math.random();
    const egg=r<0.60?"fan":r<0.85?"ling":r<0.95?"xuan":"di";
    S.eggs[egg]++;
    S.eggsGot++;
    msgs.push(`🥚 机缘蛋现世（${GX.EGGS[egg].name}）`);
  }
  if(msgs.length)log("✨ 机缘：" + msgs.join("；"),"good");
}

/* ---- 采药 / 历练（pending 定义在 main.js，运行时可见） ---- */
function startHerb(){
  if(pending.herb)return;
  pending.herb={t:performance.now()+15000};
  log("你负箧采药，深入山林…（15秒）");
  render();
}
function startRoam(){
  if(pending.roam)return;
  pending.roam={t:performance.now()+45000};
  const risk=Math.round((1-Math.min(0.85,0.25+(1-S.life/lifeCap())*0.35))*100);
  log(`你御风远游，历练四方…（45秒，胜算约 ${risk}%）`);
  render();
}

/* ---- 丹药 / 建筑 / 功法 ---- */
function usePill(k){
  const p=GX.PILLS[k];
  if(S.pills[k]<=0)return;
  S.pills[k]--;
  if(k==="juli"){
    const v=Math.ceil(layerNeed()*0.15);
    S.cult+=v;log(`服下聚灵丹，修为 +${fmt(v)}（本层需求15%）`,"good");
  }else if(k==="huichun"){
    const v=lifePillGain();
    S.life+=v;log(`服下回春丹，寿元 +${v} 年（随境界提升）`,"good");
  }else if(k==="xuan"){
    if(S._xuanActive){log("玄丹之力已在体内，无需再服","dim");S.pills.xuan++;return}
    S.pills.xuan=0;
    log("玄丹入腹，隐有雷光护体，下次渡劫更易渡过","good");
    S._xuanActive=true;
  }else if(k==="dujie"){
    log("渡劫丹入腹，劫雷将至时自行护体（渡劫成功率+20%）","good");
  }else if(k==="yanshou"){
    const v=lifePillGain()*4;
    S.lifeBonus=(S.lifeBonus||0)+v;
    log(`服下延寿丹，寿元上限 +${v} 年（随境界提升）`,"good");
  }
  render();
}
function craftPill(k){
  const c=pillCost(k);
  if(S.spirit<c)return;
  S.spirit-=c;
  S.pills[k]++;
  log(`炼丹成功：${GX.PILLS[k].icon}${GX.PILLS[k].name} ×1（耗灵石 ${fmt(c)}）`,"good");
  render();
}
function buyBld(id){
  const b=GX.BLDS.find(x=>x.id===id);
  if(id==="altar"&&S.realmIdx<3){log("道坛灵机未开，元婴方可设坛","dim");return}
  const cost=bldCost(id);
  if(S.spirit<cost)return;
  S.spirit-=cost;
  S.bld[id]++;
  log(`洞府扩建：${b.icon}${b.name} 升至 ${S.bld[id]} 级（耗灵石 ${fmt(cost)}）`,"good");
  render();
}
function buyGongfa(){
  if(S.gongfaLv>=gongfaMaxLv()){log("功法已至当前境界所能承载的品阶，待境界提升再参悟","dim");return}
  const cost=gongfaCost();
  if(S.spirit<cost)return;
  S.spirit-=cost;
  S.gongfaLv++;
  const tier=GX.GONGFA_TIERS[S.gongfaLv-1].name;
  log(`功法参悟至第 ${S.gongfaLv} 重（${tier}），修炼心得大增！`,"good");
  render();
}

/* ---- 炼器（法宝）---- */
function forgeTreasure(q,free){
  const need=shardCost(q);
  if(!free&&S.shards[need.key]<need.n)return;
  if(!free)S.shards[need.key]-=need.n;
  // 随机器型
  const types=Object.keys(GX.TREASURE_TYPES);
  const type=types[Math.random()*types.length|0];
  // 替换旧法宝：折算 60% 灵石；旧词条按级 30% 概率继承到新法宝
  let keep={};
  if(S.treasure){
    const refund=Math.ceil(GX.TREASURES[S.treasure.q-1].shard*0.6*(S.realmIdx+1));
    S.spirit+=refund;
    log(`旧法宝熔炼，折算灵石 ${fmt(refund)}`,"dim");
    for(const id in S.treasure.words||{})
      if((S.treasure.words[id]||0)>0&&Math.random()<0.30)keep[id]=S.treasure.words[id];
  }
  S.treasure={q,type,words:keep};
  S.forgeN++;
  const tq=GX.TREASURES[q-1], tt=GX.TREASURE_TYPES[type];
  markSeen("treasures",q+"_"+type,`${tq.name}·${tt.name}`);
  log(`🔨 炼器成：${tq.name}${tt.name}（${tt.desc(q)}）`,"good");
  if(Object.keys(keep).length)log("🔥 祭炼之火未灭旧纹，词条 <b>"+Object.keys(keep).map(id=>GX.REFINE_WORDS[id].name).join("、")+"</b> 随火转入新器","dim");
  render();
}
/* 祭炼：耗灵石+残片给当前法宝加 1 个词条（每词条 3 级封顶） */
function refineTreasure(){
  if(!S.treasure){log("尚无法宝可祭炼","dim");return}
  if(Object.keys(GX.REFINE_WORDS).every(id=>wordLevel(id)>=3)){log("法宝纹路已满，再炼无用","dim");return}
  const c=refineCost();
  if(S.spirit<c.spirit||S.shards[c.shardKey]<c.shard){log("祭炼所需的灵石或残片不足","dim");render();return}
  S.spirit-=c.spirit;S.shards[c.shardKey]-=c.shard;
  const avail=Object.keys(GX.REFINE_WORDS).filter(id=>wordLevel(id)<3);
  const id=avail[Math.random()*avail.length|0];
  S.treasure.words=S.treasure.words||{};
  S.treasure.words[id]=(S.treasure.words[id]||0)+1;
  log(`🔥 祭炼成：本命法宝铭刻 <b>${GX.REFINE_WORDS[id].name}</b>（${GX.REFINE_WORDS[id].desc(S.treasure.words[id])}），耗灵石 ${fmt(c.spirit)}、残片 ×${c.shard}`,"good");
  render();
}
function releaseEgg(kind){
  if(S.eggs[kind]<=0)return;
  S.eggs[kind]--;
  const price=eggPrice(kind);
  S.spirit+=price;
  log(`放生 ${GX.EGGS[kind].name}灵兽蛋，换灵石 ${fmt(price)}`,"dim");
  render();
}
/* 灵兽蛋孵化升星：蛋→灵兽，每只 +2% 全产出（至多 5 星 10%） */
function hatchEgg(kind){
  if(S.eggs[kind]<=0)return;
  const cap=GX.BEASTS[kind].stars;
  const have=S.beasts[kind];
  if(have>=cap){log(`${GX.EGGS[kind].name}灵兽已至 ${cap} 星，蛋可继续放生`,"dim");render();return}
  S.eggs[kind]--;
  S.beasts[kind]=have+1;
  markSeen("beasts",kind,GX.BEASTS[kind].name);
  log(`🐣 ${GX.EGGS[kind].name}灵兽蛋孵化，${GX.BEASTS[kind].name} 升至 ${S.beasts[kind]} 星（全产出 +${S.beasts[kind]*2}%）`,"good");
  render();
}
/* ---- 秘境挑战（文字 3 回合抉择 + 终局结算；每境界解锁一个，冷却 300 秒）----
   复用 trib.js 的 openChoice 面板；secretOpen 期间 tick 冻结（同 beginOpen） */
let secretOpen=false,secretTurn=0,secretOpts=[];
function currentSecret(){
  let cur=null;
  for(const s of GX.SECRETS)if(S.realmIdx>=s.minRealm)cur=s;
  return cur;
}
function openSecret(){
  if(secretOpen||encounterOpen||tribOpen)return;
  const s=currentSecret();
  if(!s){log("山雾未开，尚无可探之秘境","dim");return}
  if(S.secretCd>0){log(`秘境灵机未复，尚需 ${fmtTime(S.secretCd)}`,"dim");return}
  S.secretCd=GX.SECRET_CD; // 入场即扣冷却（早退不返还）
  secretOpen=true;secretTurn=0;
  drawSecretRound();
}
function drawSecretRound(){
  const s=currentSecret();
  const pool=GX.SECRET_EVENTS.filter(e=>S.realmIdx>=e.minRealm);
  const ev=pool[Math.random()*pool.length|0];
  secretTurn++;
  const opts=ev.options().map(o=>({label:o.label,detail:o.detail,act:()=>{
    const res=o.act();
    log(`🏔️ ${s.name} · ${secretTurn}/3：${res}`,res.includes("-")||res.includes("伤")?"bad":"good");
    secretNext();
  }}));
  opts.push({label:"就此退出",detail:"结算已得机缘",act:()=>{
    log(`🏔️ ${s.name}：你收敛气息，退出秘境`,"dim");
    secretFinish();
  }});
  secretOpts=opts;
  openChoice(`🏔️ 秘境 · ${s.name}（${secretTurn}/3）`,ev.text,opts);
}
function secretNext(){
  encounterOpen=false;tribOpen=false;tribOpts=[]; // 让出面板给下一回合
  if(secretTurn>=3){secretFinish();return}
  drawSecretRound();
}
function secretFinish(){
  // 终局结算：基础灵石（锚定 mineRate，回合数越多加成越高）+ 30% 道果
  const base=Math.ceil(Math.max(60,mineRate()*60)*(1+secretTurn*0.1));
  S.spirit+=base;
  let txt=`秘境机缘落定：灵石 +${fmt(base)}`;
  if(Math.random()<0.30){S.daoHeart=(S.daoHeart||0)+1;txt+="，道心 +1"}
  log("🏔️ "+txt,"good");
  closeEncounter();
  secretOpen=false;secretOpts=[];
  render();
}

/* 闭关：120 秒内自动按点击力的 60%/秒 累积修为，期间不可修炼/突破 */
function startMed(){
  if(S.med>0)return;
  S.med=120;
  log("🧘 你盘坐入定，闭关 120 秒。期间修为按点击力 ×5/秒 自动凝练（等同疾点），不可修炼、不可渡劫。","good");
  render();
}
