"use strict";
/* ============ 核心层：工具 / 事件总线 / 渲染特效 ============ */
const $=id=>document.getElementById(id);

function fmt(n){
  if(!isFinite(n))return"∞";
  if(n<0)return"-"+fmt(-n);
  if(n<1000)return(n%1?n.toFixed(1):String(n));
  const u=["","千","万","亿","兆","京"];
  let i=0;
  while(n>=1000&&i<u.length-1){n/=1000;i++}
  return(n<10?n.toFixed(2):n<100?n.toFixed(1):String(Math.floor(n)))+u[i];
}
function fmtTime(s){
  s=Math.max(0,Math.ceil(s));
  if(s<60)return s+"秒";
  if(s<3600)return Math.floor(s/60)+"分"+(s%60? (s%60)+"秒":"");
  return Math.floor(s/3600)+"时"+Math.floor(s%3600/60)+"分";
}

function log(txt,cls){
  const li=document.createElement("li");
  if(cls)li.className=cls;
  li.innerHTML=txt;
  const box=$("log");
  box.insertBefore(li,box.firstChild);
  while(box.children.length>80)box.removeChild(box.lastChild);
}
function floatTxt(anchor,txt,cls){
  if(!anchor)return;
  const r=anchor.getBoundingClientRect();
  const el=document.createElement("div");
  el.className="float-txt"+(cls?" "+cls:"");
  el.textContent=txt;
  el.style.left=(r.left+r.width/2-20+Math.random()*30-15)+"px";
  el.style.top=(r.top-6)+"px";
  document.body.appendChild(el);
  setTimeout(()=>el.remove(),1100);
}
function tipShow(html,ev){
  const t=$("tip"); t.innerHTML=html; t.hidden=false;
  const w=260;
  t.style.left=Math.min(innerWidth-w-10,ev.clientX+14)+"px";
  t.style.top=(ev.clientY+14)+"px";
}
function tipHide(){$("tip").hidden=true}

let sealT=null;
function fxPulse(){
  const fx=$("fx");
  fx.classList.add("go");
  setTimeout(()=>fx.classList.remove("go"),500);
  const se=$("seal");
  se.classList.add("show");
  clearTimeout(sealT);
  sealT=setTimeout(()=>se.classList.remove("show"),1000);
  const c=$("coreWrap");
  c.classList.add("broke");
  setTimeout(()=>c.classList.remove("broke"),800);
}

/* ============ 存档（带版本迁移） ============ */
const SAVE_KEY="wenzixiuxian_v2";
function save(){
  S.lastTs=Date.now();
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(S))}catch(e){}
  $("saveInfo").textContent="已自动保存 "+new Date().toLocaleTimeString();
}
function load(){
  try{
    let raw=localStorage.getItem(SAVE_KEY);
    if(raw){
      const d=JSON.parse(raw);
      S=freshState();
      Object.assign(S,d);
      return migrate(S);
    }
    // 兼容 v1 存档
    const old=localStorage.getItem("wenzixiuxian_v1");
    if(old){
      const d=JSON.parse(old);
      S=freshState();
      Object.assign(S,d);
      return migrate(S);
    }
  }catch(e){}
  S=freshState();
  return false;
}
function migrate(d){
  d.buffs=d.buffs||{tide:0,shock:0};
  d.secretCd=d.secretCd||0;
  d.bld=Object.assign({zhen:0,mine:0,beast:0,furn:0,forge:0,altar:0},d.bld);
  d.pills=Object.assign({juli:0,huichun:0,xuan:0,dujie:0,yanshou:0},d.pills);
  d.shards=Object.assign({fan:0,ling:0,xuan:0,di:0},d.shards);
  d.eggs=d.eggs||{fan:0,ling:0,xuan:0,di:0};
  d.beasts=Object.assign({fan:0,ling:0,xuan:0,di:0},d.beasts);
  d.treasure=d.treasure||null;
  d.daoHeart=d.daoHeart||0;d.med=d.med||0;
  d.daoFruit=d.daoFruit||0;d.tribFails=d.tribFails||0;
  d._pend=d._pend||{};
  d.constitution=d.constitution||null;
  d.tribBless=!!d.tribBless;
  d.seen=Object.assign({roots:{},treasures:{},beasts:{},encs:{},tao:{}},d.seen);
  d.taoMax=Math.max(1,Math.min(5,d.taoMax||1));d.taoKills=d.taoKills||0;d.taoBoss=d.taoBoss||0;
  d.breaks=d.breaks||0;d.clicks=d.clicks||0;d.forgeN=d.forgeN||0;
  d.eggsGot=d.eggsGot||0;d.encN=d.encN||0;d.achieved=d.achieved||{};
  d.gongfaLv=Math.max(1,Math.min(d.gongfaLv||1,GX.GONGFA_TIERS.length)); // 品阶化：旧档超 7 重收敛
  if(!d.root)d.root=rollRoots(1)[0];
  d.v=2;
  return true;
}
