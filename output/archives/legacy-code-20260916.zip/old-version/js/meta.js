"use strict";
/* ============ 元游戏：道果 / 图鉴 / 成就 / 离线 / 终局 / 转世 / 开局界面 ============
   跨世传承（道果+图鉴+道行）与一世的生死轮回都落此文件。 */

/* ---- 道果 & 图鉴（跨世传承）---- */
function gainFruit(n){S.daoFruit+=n;log(`🍑 凝成道果 +${n}`,"good")}
function markSeen(group,key,name){
  if(!S.seen)S.seen={roots:{},treasures:{},beasts:{},encs:{}};
  if(S.seen[group][key])return;
  S.seen[group][key]=Date.now();
  log(`📖 道果图鉴点亮：<b>${name}</b>（全产出 +0.5%）`,"dim");
}

/* ---- 转世商店（道果 = 纯货币，转世界面购买，入世生效）----
   道果不再给被动加成；S.shopBought 记录限领商品（每世一次），S._pend 暂存生效内容 */
let shopBought={};
function buyShop(id){
  if(!beginOpen)return;
  const it=GX.SHOP.find(x=>x.id===id);
  if(!it||S.daoFruit<it.cost)return;
  if(!it.repeat&&shopBought[id])return;
  S.daoFruit-=it.cost;
  if(!it.repeat)shopBought[id]=true;
  const p=S._pend;
  if(id==="reroll")p.reroll=1;
  else if(id==="provision"){
    // 随世数上涨：每世 +20%（锚定当前世数 S.times+1）
    p.provSpirit=(p.provSpirit||0)+Math.ceil(2500*Math.pow(1.2,S.times));
    p.provCult=(p.provCult||0)+Math.ceil(1000*Math.pow(1.2,S.times));
  }
  else if(id==="pills")p.pills=(p.pills||0)+1;
  else if(id==="shards")p.shards=(p.shards||0)+1;
  else if(id==="egg")p.egg=(p.egg||0)+1;
  else if(id==="prestige")p.prestige=(p.prestige||0)+1;
  else if(id==="tribbless")p.tribbless=1;
  else if(id==="daoheart")p.daoheart=(p.daoheart||0)+1;
  else if(id==="dharma")p.dharma=1;
  else if(id==="constitution")p.constitution=GX.CONSTITUTIONS[Math.random()*GX.CONSTITUTIONS.length|0];
  log(`🏮 转世商店购入：<b>${it.name}</b>（道果 -${it.cost}），入世生效`,"good");
  render();
  drawShop();
}
/* 入世时结算暂存（commitBegin 调用）；重载后未入世的暂存由 start() 结算 */
function applyShopPurchases(){
  const p=S._pend;if(!p)return;
  const msgs=[];
  if(p.reroll)beginRerolls+=p.reroll, msgs.push(`重抽 +${p.reroll} 次`);
  if(p.provSpirit){S.spirit+=p.provSpirit;S.cult+=p.provCult;msgs.push(`灵石 +${fmt(p.provSpirit)}、修为 +${fmt(p.provCult)}`)}
  if(p.pills){S.pills.dujie+=p.pills;S.pills.juli+=2*p.pills;msgs.push("渡劫丹×1、聚灵丹×2")}
  if(p.shards){S.shards.fan+=10*p.shards;msgs.push("凡品残片×10")}
  if(p.egg){S.eggs.xuan+=p.egg;msgs.push("玄品灵兽蛋×1")}
  if(p.prestige){S.prestige+=p.prestige;msgs.push(`道行 +${p.prestige}`)}
  if(p.tribbless){S.tribBless=true;msgs.push("天劫庇佑（本世渡劫 +12%）")}
  if(p.daoheart){S.daoHeart=(S.daoHeart||0)+p.daoheart*5;msgs.push(`道心 +${p.daoheart*5}`)}
  const grantWord=(t)=>{
    t.words=t.words||{};
    const avail=Object.keys(GX.REFINE_WORDS).filter(id=>(t.words[id]||0)<3);
    const wid=avail.length?avail[Math.random()*avail.length|0]:null;
    if(wid){t.words[wid]=(t.words[wid]||0)+1;return `预铭 ${GX.REFINE_WORDS[wid].name}·1`}
    return "词条已满";
  };
  if(p.word){
    S.treasure=S.treasure||{q:1,type:Object.keys(GX.TREASURE_TYPES)[0]};
    msgs.push("本命法宝"+grantWord(S.treasure));
  }
  if(p.dharma){
    const type=Object.keys(GX.TREASURE_TYPES)[Math.random()*3|0];
    S.treasure={q:2,type,words:{}};
    markSeen("treasures","2_"+type,`灵品·${GX.TREASURE_TYPES[type].name}`);
    msgs.push(`先天法宝：灵品${GX.TREASURE_TYPES[type].name}，${grantWord(S.treasure)}`);
  }
  if(p.constitution){
    S.constitution=p.constitution.id;
    msgs.push(`觉醒先天之体：<b>${p.constitution.name}</b>（${p.constitution.desc}）`);
  }
  S._pend={};
  if(msgs.length)log("🏮 转世商店之物已交付：" + msgs.join("、"),"good");
}

/* ---- 成就 ---- */
function checkAchievements(){
  for(const a of GX.ACHIEVEMENTS){
    if(S.achieved[a.id])continue;
    if(a.check(S)){
      S.achieved[a.id]=Date.now();
      log(`🏮 成就达成：<b>${a.name}</b>（${a.desc}，${a.fx}）`,"good");
    }
  }
}

/* ---- 离线收益（cap 8h，仅自动产出）---- */
function offlineEarnings(){
  const now=Date.now();
  let away=(now-(S.lastTs||now))/1000;
  if(away<120)return 0; // 离开 <2 分钟不计
  const dt=Math.min(away,GX.OFFLINE_CAP);
  const dz=zhenRate()*dt, dm=mineRate()*dt;
  S.cult+=dz;S.spirit+=dm;
  if(dz>0||dm>0)
    log(`🌙 离线 ${fmtTime(dt)}：修为 +${fmt(dz)}，灵石 +${fmt(dm)}`,"dim");
  S.lastTs=now;
  return dt;
}

/* ---- 终局：死亡 / 飞升 / 转世 ---- */
let ended=false;
function die(cause){
  if(ended)return;
  ended=true;
  const gain=prestigeGain();
  const msg=cause==="坐化"?`寿元耗尽，<b>${S.name}</b> 于洞府中坐化…`:`<b>${S.name}</b> ${cause}…`;
  log(msg+(gain>0?`（道行 +${gain}）`:""),"bad");
  showEndScreen(cause,gain);
}
/* 飞升（渡劫期圆满）：不入终局，踏入仙界——真仙/玄仙/金仙/大罗，证道飞升才是真终局 */
function doAscend(){
  if(ended)return;
  const next=GX.REALMS[GX.TRIB_REALM+1];
  S.realmIdx=GX.TRIB_REALM+1;S.layer=0;
  S.life=Math.max(S.life,next.life*0.5); // 仙体重铸，寿元抬升
  log(`🌅 金光大作，<b>${S.name}</b> 渡劫圆满，飞升上界，位列仙班！踏入 <b>${next.name}</b> 之境（道果待轮回方结）`,"good");
  fxPulse();
  render();
}
/* 证道飞升（大罗圆满，真终局） */
function doAscendFinal(){
  if(ended)return;
  ended=true;
  const gain=prestigeGain();
  log(`🌅 天道默然让位，<b>${S.name}</b> 证道飞升，超脱三界！（道果待轮回方结）`,"good");
  fxPulse();
  showEndScreen("证道",gain);
}
function showEndScreen(cause,gain){
  const t=document.createElement("div");
  t.style.cssText="position:fixed;inset:0;background:rgba(5,8,12,.93);z-index:200;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;padding:24px;text-align:center";
  const title=cause==="证道"?"证道飞升":cause==="飞升"?"飞升成仙":"羽化登遐";
  const ico=cause==="证道"?"🌄":cause==="飞升"?"🌅":"🕯️";
  const sub=cause==="证道"?"道在朝夕，一念万年。":"转世后一切归零，唯道心不灭。";
  t.innerHTML=`
    <div style="font-size:40px">${ico}</div>
    <div style="font-family:var(--font-brush);font-size:36px;color:var(--gold2);letter-spacing:8px">${title}</div>
    <div style="color:var(--dim);max-width:500px;font-size:14px">${S.name} 一世修行至此。${gain>0?`凝练道行 <b style="color:var(--gold2)">+${gain}</b>，每点永久提升全产出 3%。`:"转世后一切归零，唯道心不灭。"}${sub}</div>
    <div id="endBtn" style="font-size:18px;padding:12px 30px;border-color:var(--gold);color:var(--gold2)">转世重修（择灵根）</div>`;
  document.body.appendChild(t);
  t.querySelector("#endBtn").onclick=()=>{
    reincarnate(gain);
    log(`☯️ 转世重生，道行 ${gain}（全产出 +${gain*3}%）`,"good");
    t.remove();
  };
}
function reincarnate(gain){
  markSeen("roots",S.root,GX.ROOTS[S.root].name); // 一世走完：点亮本世灵根（重复根不再加）
  shopBought={}; // 新世重开限购
  const t=S.times+1;
  const fruit=S.daoFruit, seen=S.seen; // 跨世保留：道果 + 图鉴
  // 轮回结道果：一生只在轮回时按此生修为结算（元婴以下未凝，证道圆满加赠）
  const lf=lifeFruit();
  if(lf>0)log(`🍑 轮回之刻，一世道行凝成果实：道果 +${lf}`,"good");
  S=freshState();
  S.prestige=gain;S.times=t;S.name="无名道修";S.life=1;
  S.daoFruit=fruit+lf;S.seen=seen;
  ended=false;
  battle=null; // 一世走完，缠斗随尘缘而散
  last=performance.now();
  save();
  render();
  openBegin("again");
}
function doPrestige(){
  const gain=prestigeGain();
  if(gain<=0){
    if(S.times<1)log("初入尘世，尚无转世资格","dim");
    else log("未至渡劫圆满，转世收益不足","dim");
    return;
  }
  log(`☯️ 主动放下此世修为，凝练道行 <b>+${gain}</b>（全产出 +${gain*3}%）`,"good");
  reincarnate(gain);
}

/* ---- 开局/转世界面（小窗口；入世前 tick 冻结） ----
   kind: "new"=原始开局（无存档）/道途清档，"again"=转世或飞升后；有存档直接入世不弹 */
let beginOpen=false,beginPending=null,beginRerolls=0,beginDraw=null;
function openBegin(kind){
  const box=$("beginBox");
  if(!box)return;
  beginOpen=true;
  const lifeNo=S.times+1;
  beginPending=rollRoots(1)[0];
  beginRerolls=3;
  const sub=kind==="new"?"文字修仙 · 道在朝夕":
    `第 ${lifeNo} 世 · 道行 ${S.prestige} · 道果 ${S.daoFruit}`;
  box.innerHTML=`
    <div class="begin-card">
      <div class="begin-title">尘缘仙途</div>
      <div class="begin-sub">${sub}</div>
      <div class="begin-root" id="beginRoot"></div>
      <button class="btn-sm" id="beginReroll" style="margin-bottom:12px"></button>
      <div class="shop" id="beginShop"></div>
      <button id="beginEnter" class="primary wide" style="width:100%;min-height:52px;margin-top:12px"></button>
    </div>`;
  box.hidden=false;
  const rootEl=box.querySelector("#beginRoot"),rr=box.querySelector("#beginReroll");
  const drawRoot=()=>{
    const r=GX.ROOTS[beginPending];
    rootEl.innerHTML=`${r.icon} ${r.name}<small>${r.desc}</small>`;
    rr.textContent=beginRerolls>0?`☯️ 重抽道缘（余 ${beginRerolls} 次）`:"道缘已现三次，天机不再变";
    rr.disabled=beginRerolls<=0;
  };
  beginDraw=drawRoot;
  drawRoot();
  drawShop();
  rr.onclick=rerollBegin;
  const enter=box.querySelector("#beginEnter");
  enter.textContent=kind==="new"?"入 世 修 行":`转 世 重 修（第 ${lifeNo} 世）`;
  enter.onclick=commitBegin;
}
/* 转世商店面板（开局窗内；道果余额 + 商品列表） */
function drawShop(){
  const el2=$("beginShop");
  if(!el2)return;
  let h=`<div class="shop-t">转世商店 <span class="shop-b">道果 <b>${S.daoFruit}</b></span></div>`;
  for(const it of GX.SHOP){
    const sold=!it.repeat&&shopBought[it.id];
    const can=beginOpen&&!sold&&S.daoFruit>=it.cost;
    h+=`<button class="shop-it ${can?"":"off"}" data-shop="${it.id}" ${can?"":"disabled"}>
      <span class="shop-n">${it.name}</span><small>${it.desc}</small>
      <span class="shop-c">${sold?"已领":"🍑 "+it.cost}</span></button>`;
  }
  el2.innerHTML=h;
  el2.querySelectorAll("[data-shop]").forEach(b=>b.onclick=()=>buyShop(b.dataset.shop));
}
/* 重抽道缘（每世限 3 次；抽到的根不点亮图鉴，入世才落定） */
function rerollBegin(){
  if(!beginOpen||beginRerolls<=0)return;
  beginRerolls--;
  beginPending=rollRoots(1)[0];
  beginDraw();
}
/* 入世：落定灵根、结算转世商店、解冻世界（灵根图鉴需走完整世才点亮，见 reincarnate） */
function commitBegin(){
  if(!beginOpen||!beginPending)return; // 开局窗未开时不可入世（防 S.root 落空）
  S.root=beginPending;
  applyShopPurchases();
  log(`☯️ 道心映根，觉醒 <b>${GX.ROOTS[S.root].icon}${GX.ROOTS[S.root].name}</b>：${GX.ROOTS[S.root].desc}`,"good");
  save();
  closeBegin();
}
function closeBegin(){
  beginOpen=false;
  const box=$("beginBox");
  if(box)box.hidden=true;
  last=performance.now();
  render();
}
