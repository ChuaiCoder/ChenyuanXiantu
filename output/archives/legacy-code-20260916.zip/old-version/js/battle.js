"use strict";
/* ============ 讨伐战斗：自动流回合攻防 ============
   独立讨伐入口（页签「讨伐」墨图 5 节点顺序解锁）；
   默认自动出手（1.6 秒/回合），可随时切手动，介入法宝/灵兽/丹药/守御/撤退。
   战斗池为局内气血（不落寿元）；败退重伤 15 秒 + 修为 -5%；奖励锚定 mineRate/cultPerClick/itemTier。
   战斗不冻结世界（同奇遇，事件式）；S.taoCd 讨伐冷却 30 秒。 */

/* battle=null 无战斗；对象 {node,eHp,eMax,e,pPh,pMax,turn,pAuto,guard,xuan,dujie,acc} */
let battle=null;

/* 节点 n 当前境界下的妖兽（实时生成：境界抬升，旧节点也变强，刷奖励永远有值） */
function taoEnemy(n){
  const m=GX.TAO_MAP[n-1],boss=n===5;
  const t=itemTier();
  return {
    name:m.beast, icon:m.icon,
    // 难度梯度：节点1-2 稳胜、3-4 险胜、5 妖主要丹药/法宝/灵兽介入（敌血/敌攻均锚定玩家自身，境界抬升比值恒定）
    hp:Math.ceil(taoHp()*(1.0+0.25*(n-1))*(boss?1.35:1)),
    atk:Math.ceil(taoAtk()*(0.5+0.09*n)*(boss?1.45:1)),
    spirit:Math.ceil(Math.max(30,mineRate()*(12+n*10))*(boss?1.6:1)),
    cult:Math.ceil(cultPerClick()*(8+n*5)*(boss?2:1)),
    shardKey:boss?"ling":"fan",
    shardN:1+(boss?1:0),
  };
}

/* 开战（同一时间仅一场；闭关/开局窗/秘境中不可出战） */
function taoStart(n){
  if(battle||S.taoCd>0||S.med>0||beginOpen||secretOpen)return;
  if(n<1||n>5||n>S.taoMax)return;
  const e=taoEnemy(n);
  const hp=taoHp();
  battle={node:n,eHp:e.hp,eMax:e.hp,e,pPh:hp,pMax:hp,turn:0,pAuto:1,guard:false,xuan:0,dujie:0,acc:0};
  log(`⚔️ 你踏入 <b>${GX.TAO_MAP[n-1].name}</b>，${e.name} 拦路！（自动作战，可随时介入）`,"good");
  render();
}

/* 玩家一回合（strike/treasure/beast/guard/pill_x）；自动与手动共用 */
function taoAct(k){
  if(!battle)return;
  const b=battle,m=GX.TAO_MAP[b.node-1],en=b.e.name;
  if(k.startsWith("pill_")){
    const pk=k.slice(5);
    if(S.pills[pk]<=0){log("无此丹药可服","dim");return}
    S.pills[pk]--;
  }
  b.turn++;
  let pTxt="",pDmg=0;
  if(k==="strike"||k==="treasure"||k==="beast"||k==="pill_juli"){
    pDmg=taoAtk()*(1+beastStars()*0.06);
    if(k==="treasure")pDmg*=2;
    if(k==="beast")pDmg*=1.5;
    if(k==="pill_juli")pDmg*=4;
    if(b.xuan>0)pDmg*=1.3;
    pDmg=Math.ceil(pDmg*(0.85+Math.random()*0.3));
    b.eHp=Math.max(0,b.eHp-pDmg);
    pTxt=`${k==="treasure"?"你催动本命法宝，法光荡出":k==="beast"?"灵兽随你扑出":k==="pill_juli"?"聚灵丹炸开，灵气贯体一击":"你出手击落"} ${en} -${fmt(pDmg)}`;
  }else if(k==="guard"){
    b.guard=true;pTxt="你沉气守御（下次受创 -60%）";
  }else if(k==="pill_xuan"){
    b.xuan=5;pTxt="玄丹护体，五回合内攻势 +30%";
  }else if(k==="pill_dujie"){
    b.dujie=5;pTxt="渡劫丹凝罡，五回合内减伤 +25%";
  }else if(k==="pill_huichun"){
    const v=Math.ceil(b.pMax*0.5);
    b.pPh=Math.min(b.pMax,b.pPh+v);
    pTxt=`回春丹入体，气血 +${fmt(v)}`;
  }
  // 敌方回合
  let ed=Math.ceil(b.e.atk*(0.85+Math.random()*0.3));
  ed=Math.ceil(ed*(1-taoDefPct()));
  const g=b.guard;
  if(g){ed=Math.ceil(ed*0.4);b.guard=false}
  if(b.dujie>0)ed=Math.ceil(ed*0.75);
  b.pPh=Math.max(0,b.pPh-ed);
  if(b.xuan>0)b.xuan--;
  if(b.dujie>0)b.dujie--;
  log(`⚔️ ${m.name} · ${en}（回合 ${b.turn}）：${pTxt} → ${en} 反扑 你 -${fmt(ed)}${g?"（守御）":""}`,pDmg>0?"good":"dim");
  if(b.eHp<=0){taoFinish(true);return}
  if(b.pPh<=0){taoFinish(false);return}
  render();
}

/* 自动模式：每 1.6 秒代玩家出招（dt 由 tick 传入） */
function taoAutoTick(dt){
  if(!battle)return;
  if(!battle.pAuto){battle.acc=0;return}
  battle.acc+=dt;
  let n=0;
  while(battle&&battle.acc>=1.6&&n<4){battle.acc-=1.6;taoAct("strike");n++}
  if(battle&&battle.acc>6.4)battle.acc=6.4; // 切后台回来不爆回合
}

/* 切换自动/手动、撤退 */
function taoToggle(){if(battle){battle.pAuto=battle.pAuto?0:1;render()}}
function taoFlee(){
  if(!battle)return;
  const n=battle.node;battle=null;
  S.taoCd=30;
  log(`你敛息退走，此战未定（${GX.TAO_MAP[n-1].name}）`,"dim");
  render();
}

/* 胜负结算 */
function taoFinish(win){
  const b=battle;battle=null;
  const m=GX.TAO_MAP[b.node-1],e=b.e;
  if(win){
    S.spirit+=e.spirit;S.cult+=e.cult;
    S.shards[e.shardKey]+=e.shardN;
    if(S.taoMax<5&&b.node>=S.taoMax)S.taoMax++;
    S.taoKills++;
    if(b.node===5){S.taoBoss++;markSeen("tao","5","五感妖主")}
    log(`⚔️ <b>${e.name}</b> 败：灵石 +${fmt(e.spirit)}、修为 +${fmt(e.cult)}、${e.shardKey==="ling"?"灵品":"凡品"}残片 ×${e.shardN}${S.taoMax<5?` —— <b>${GX.TAO_MAP[S.taoMax-1].name}</b> 现世`:""}`,"good");
  }else{
    const loss=Math.ceil(S.cult*0.05);
    S.cult=Math.max(0,S.cult-loss);
    S.buffs.shock=Math.max(S.buffs.shock,15);
    log(`💥 不敌 ${e.name}，重伤退走：修为 -${fmt(loss)}，重伤 15 秒`,"bad");
  }
  S.taoCd=30;
  render();
}
