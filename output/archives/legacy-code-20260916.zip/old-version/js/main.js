"use strict";
/* ============ 主循环 ============ */
let S=null, tickTimer=null, last=0, saveTimer=0, eventTimer=0, encTimer=0, furnTimer=0, tickN=0;
const pending={herb:null,roam:null};
const renderKey={pills:"",bld:"",forge:"",egg:"",ach:"",codex:""};

function tick(){
  if(beginOpen||secretOpen)return; // 开局/转世/秘境抉择中，世界静止
  const now=performance.now();
  let dt=(now-last)/1000; last=now;
  if(dt<=0)return;
  if(dt>5)dt=5; // 标签页切后台保护
  tickN++;

  const speed=(S.buffs.tide>0?2:1)*(S.buffs.shock>0?0.5:1);

  // 自动修为/灵石
  const dz=zhenRate()*dt*speed, dm=mineRate()*dt*speed;
  if(dz>0){S.cult+=dz; if(Math.random()<0.15)floatTxt($("btnCultivate"),"+"+fmt(dz/1),"");}
  if(dm>0){S.spirit+=dm;}

  // 道坛：燃烧灵石凝练修为（灵石后期出口；闭关/重伤期间灵台不宁不烧）
  const alt=altarRate();
  if(alt>0&&S.med<=0&&S.buffs.shock<=0){
    const burn=Math.min(S.spirit,alt*dt);
    if(burn>0){S.spirit-=burn;S.cult+=burn*speed; if(Math.random()<0.05)floatTxt($("btnCultivate"),"🏮+"+fmt(burn*speed/5),"");}
  }

  // 闭关：按点击力 ×3/秒 自动凝练
  if(S.med>0){
    S.med=Math.max(0,S.med-dt);
    S.cult+=cultPerClick()*5*dt*speed;
    if(S.med===0)log("🧘 闭关功成，缓缓出定。","good");
  }

  // 寿元
  S.life+=dt/3600;
  if(S.life>=lifeCap()){die("坐化");return}

  // buff / 秘境 / 讨伐冷却 倒计时
  if(S.buffs.tide>0)S.buffs.tide-=dt;
  if(S.buffs.shock>0)S.buffs.shock-=dt;
  if(S.secretCd>0)S.secretCd=Math.max(0,S.secretCd-dt);
  if(S.taoCd>0)S.taoCd=Math.max(0,S.taoCd-dt);
  taoAutoTick(dt); // 讨伐自动回合（战斗中才有效）

  // 丹房自动炼丹
  if(S.bld.furn>0){
    furnTimer+=dt;
    if(furnTimer>=60){
      furnTimer-=60;
      if(S.spirit>=5){S.spirit-=5;S.pills.juli++;log("丹房自动炼出一粒聚灵丹","good");}
    }
  }

  // 任务结算
  if(pending.herb&&now>=pending.herb.t){
    pending.herb=null;
    const st=S.life/lifeCap();
    const spirit=Math.ceil(Math.max(20,mineRate()*20)*(0.7+Math.random()*0.6));
    let txt=`采药归来，得灵石 <b>${fmt(spirit)}</b>`;
    const roll=Math.random();
    if(st<0.5&&roll<0.25){
      const p=GX.PILLS[Math.random()<0.5?"juli":"huichun"];
      S.pills[p.name==="聚灵丹"?"juli":"huichun"]++;
      txt+=`，偶得 <b>${p.icon}${p.name}</b> 一枚`;
    }else if(roll<0.12){
      S.cult+=Math.ceil(cultPerClick()*8);
      txt+=`，悟得一丝灵气（修为+${fmt(cultPerClick()*8)}）`;
    }
    S.spirit+=spirit;
    log(txt,"good");
    floatTxt($("btnHerb"),"+"+fmt(spirit)+"灵石");
  }
  if(pending.roam&&now>=pending.roam.t){
    pending.roam=null;
    const risk=1-Math.min(0.85,0.25+(1-S.life/lifeCap())*0.35);
    if(Math.random()<risk){
      const spirit=Math.ceil(Math.max(40,mineRate()*40)*(1+Math.random()));
      const cult=Math.ceil(cultPerClick()*25*(0.8+Math.random()*0.4));
      S.spirit+=spirit;S.cult+=cult;
      log(`历练凯旋！灵石 <b>${fmt(spirit)}</b>、修为 <b>${fmt(cult)}</b>，机缘造化！`,"good");
      floatTxt($("btnRoam"),"机缘+");
    }else{
      const dmg=Math.ceil(cultPerClick()*40);
      S.cult=Math.max(0,S.cult-dmg);
      S.buffs.shock=Math.max(S.buffs.shock,20);
      log(`历练遇伏，身受重伤，修为受损 ${fmt(dmg)}，需 20 秒疗伤…`,"bad");
      floatTxt($("btnRoam"),"重伤","bad");
    }
  }

  // 随机事件（环境向）
  eventTimer+=dt;
  if(eventTimer>=GX.EVENT_EVERY){
    eventTimer=0;
    randomEvent();
  }

  // 成就（低频轮询）
  if(tickN%15===0)checkAchievements();

  // 奇遇（选择向）
  encTimer+=dt;
  if(encTimer>=GX.ENC_EVERY&&!encounterOpen){
    encTimer=0;
    openEncounter();
  }

  render();
}

function randomEvent(){
  const st=S.life/lifeCap();
  const roll=Math.random();
  if(S.buffs.tide<=0&&roll<0.12){
    S.buffs.tide=45;
    log("⚡ 天地灵气潮汐！45 秒内所有产出 ×2","good");
  }else if(roll<0.22){
    const spirit=Math.ceil(Math.max(15,mineRate()*15)*(1+Math.random()));
    S.spirit+=spirit;
    log(`🎲 山风送来一线机缘，拾得灵石 ${fmt(spirit)}`,"good");
  }else if(st>0.5&&roll<0.32){
    const gain=Math.ceil(0.02*lifeCap());
    S.life+=gain;
    log(`🍵 偶遇前辈讲道，心境澄明，寿元 +${gain} 年`,"good");
  }else if(S.buffs.shock<=0&&st>0.4&&roll<0.42){
    const dmg=Math.ceil(cultPerClick()*10);
    S.cult=Math.max(0,S.cult-dmg);
    S.buffs.shock=15;
    log(`🐺 妖兽夜袭洞府，修为受损 ${fmt(dmg)}，疗伤 15 秒`,"bad");
  }else if(roll<0.50){
    log("🌫️ 云雾弥漫，道途寂寂，暂无奇遇","dim");
  }
}

/* ============ 页签切页（修行录为常驻右栏，不参与页签） ============ */
function switchTab(name){
  document.querySelectorAll("#tabbar .tab").forEach(t=>t.classList.toggle("active",t.dataset.tab===name));
  document.querySelectorAll("#pages .page").forEach(p=>p.classList.toggle("active",p.dataset.page===name));
}

/* ============ 事件绑定 ============ */
function bind(){
  document.querySelectorAll("#tabbar .tab").forEach(t=>{
    t.onclick=()=>switchTab(t.dataset.tab);
  });
  $("btnCultivate").onclick=e=>doCultivate(e);
  $("btnHerb").onclick=startHerb;
  $("btnRoam").onclick=startRoam;
  $("btnMed").onclick=startMed;
  $("btnSecret").onclick=openSecret;
  $("btnBreak").onclick=doBreak;
  $("btnGongfa").onclick=buyGongfa;
  $("btnPrestige").onclick=doPrestige;
  $("btnReset").onclick=()=>{
    if(confirm("确定清空全部存档，重入轮回？")){
      localStorage.removeItem(SAVE_KEY);
      localStorage.removeItem("wenzixiuxian_v1");
      S=freshState();battle=null;last=performance.now();save();render();
      log("轮回重启，道心初定","dim");
      openBegin("new");
    }
  };
  $("btnExport").onclick=()=>{
    const txt=btoa(unescape(encodeURIComponent(JSON.stringify(S))));
    prompt("复制以下存档：",txt);
  };
  $("btnImport").onclick=()=>{
    const txt=prompt("粘贴存档：");
    if(!txt)return;
    try{
      const d=JSON.parse(decodeURIComponent(escape(atob(txt.trim()))));
      S=freshState();
      Object.assign(S,d);
      migrate(S);
      save();render();log("存档导入成功","good");
    }catch(e){alert("存档格式有误")}
  };
  document.addEventListener("click",e=>{
    const t=e.target;
    if(t.dataset&&t.dataset.pill)usePill(t.dataset.pill);
    if(t.dataset&&t.dataset.craft)craftPill(t.dataset.craft);
    if(t.dataset&&t.dataset.bld)buyBld(t.dataset.bld);
    if(t.dataset&&t.dataset.forge)forgeTreasure(+t.dataset.forge);
    if(t.dataset&&t.dataset.refine)refineTreasure();
    if(t.dataset&&t.dataset.egg)releaseEgg(t.dataset.egg);
    if(t.dataset&&t.dataset.hatch)hatchEgg(t.dataset.hatch);
    if(t.dataset&&t.dataset.tao)taoStart(+t.dataset.tao);
    if(t.dataset&&t.dataset.taob)taoAct(t.dataset.taob);
    if(t.id==="btnTaoToggle")taoToggle();
    if(t.id==="btnTaoFlee")taoFlee();
  });
  $("bldBox").addEventListener("mousemove",e=>{
    const btn=e.target.closest("[data-bld]");
    if(btn){
      const b=GX.BLDS.find(x=>x.id===btn.dataset.bld);
      tipShow(`<b>${b.icon}${b.name}</b><br>${b.desc(S.bld[b.id])}`,e);
    }else tipHide();
  });
  $("bldBox").addEventListener("mouseleave",tipHide);
  document.addEventListener("keydown",e=>{
    if(e.code==="Space"&&e.target===document.body){e.preventDefault();doCultivate({target:$("btnCultivate")})}
  });
}

/* ============ 背景：墨雾 + 灵尘 ============ */
function initBG(){
  const cv=$("bg"),ctx=cv.getContext("2d");
  let W,H;
  function resize(){W=cv.width=innerWidth;H=cv.height=innerHeight}
  resize();
  addEventListener("resize",resize);
  const reduced=matchMedia("(prefers-reduced-motion:reduce)").matches;
  const puffs=[];for(let i=0;i<6;i++)puffs.push({x:Math.random()*W,y:Math.random()*H,r:260+Math.random()*340,v:4+Math.random()*9,a:.045+Math.random()*.04});
  const embers=[];for(let i=0;i<26;i++)embers.push({x:Math.random()*W,y:Math.random()*H,r:.6+Math.random()*1.6,v:.25+Math.random()*.85,ph:Math.random()*6.28,tw:.5+Math.random()});
  function frame(t){
    ctx.clearRect(0,0,W,H);
    for(const p of puffs){
      const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r);
      g.addColorStop(0,`rgba(128,152,190,${p.a})`);
      g.addColorStop(1,"rgba(128,152,190,0)");
      ctx.fillStyle=g;ctx.fillRect(p.x-p.r,p.y-p.r,p.r*2,p.r*2);
      if(!reduced){
        p.x+=p.v*.016;
        if(p.x-p.r>W){p.x=-p.r;p.y=Math.random()*H}
      }
    }
    for(const m of embers){
      const al=reduced?.35:(.22+.3*Math.abs(Math.sin(t/1000*m.tw+m.ph)));
      ctx.beginPath();ctx.arc(m.x,m.y,m.r,0,6.283);
      ctx.fillStyle=`rgba(228,196,130,${al})`;ctx.fill();
      if(!reduced){
        m.y-=m.v*.016*m.r;
        if(m.y<-4){m.y=H+4;m.x=Math.random()*W}
      }
    }
    if(!reduced)requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

/* ============ 启动 ============ */
function start(){
  const ok=load();
  if(ok){
    offlineEarnings();
    if(S._pend&&Object.keys(S._pend).length)applyShopPurchases(); // 转世商店已购未入世的，重载即交付
  }
  refreshRing();
  bind();
  initBG();
  last=performance.now();
  tickTimer=setInterval(tick,100);
  saveTimer=setInterval(save,20000);
  if(ok)log("存档读取成功，继续修行","dim");
  else log("🌄 你于一处山洞中醒来，灵气氤氲，仙途自此开始。","good");
  render();
  // 开局界面：仅在原始开局（无存档）弹出；有存档直接入世，转世时由 reincarnate 再弹
  if(!ok)openBegin("new");
}
document.addEventListener("visibilitychange",()=>{if(!document.hidden)last=performance.now()});
window.addEventListener("beforeunload",save);
start();
