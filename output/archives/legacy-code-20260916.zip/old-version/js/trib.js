"use strict";
/* ============ 突破渡劫：层劫 / 境界劫 / 天劫三渡法 / 奇遇 / 选择面板 ============
   天劫与奇遇共用 #encBox 面板（openChoice）。 */

let encounterOpen=false,tribOpen=false,tribOpts=[];

/* ---- 渡劫（突破升级）---- */
function breakInfo(){
  if(S.cult<layerNeed())return{ok:false,txt:`修为不足（${fmt(S.cult)}/${fmt(layerNeed())}）`,kind:"layer"};
  if(!isTopLayer())return{ok:true,txt:`渡本层小劫 成功率 ${Math.round(tribChance("layer")*100)}%`,kind:"layer"};
  if(S.realmIdx===GX.TRIB_REALM)return{ok:true,txt:"飞升上界！（渡劫圆满，踏入真仙）",kind:"ascend"};
  if(!isFinalRealm())return{ok:true,txt:`引动天劫·冲击 ${GX.REALMS[S.realmIdx+1].name} 成功率 ${Math.round(tribChance("realm")*100)}%`,kind:"realm"};
  return{ok:true,txt:"证道飞升！（终局）",kind:"ascend"};
}
function doBreak(){
  const info=breakInfo();
  if(!info.ok){log(info.txt,"dim");return}
  if(S.med>0){log("闭关入定，暂不能渡劫","dim");return}
  if(info.kind==="ascend"){if(S.realmIdx===GX.TRIB_REALM)doAscend();else doAscendFinal();return}
  // 渡劫期层劫 / 仙界劫层 → 天劫选择面板（三渡法）
  if(info.kind==="layer"&&(S.realmIdx===GX.TRIB_REALM||(S.realmIdx>GX.TRIB_REALM&&isXianTriLayer()))){openTribulation();return}
  const success=Math.random()<tribChance(info.kind);
  // 渡劫丹自动消耗
  if(S.pills.dujie>0){S.pills.dujie--;log("渡劫丹自行燃尽护体…","dim")}
  if(S._xuanActive){S._xuanActive=false;S.pills.xuan=Math.max(0,S.pills.xuan)}
  if(success){
    // 只扣除本次所需修为，多余保留
    S.cult=Math.max(0,S.cult-layerNeed());
    S.breaks++;
    if(info.kind==="layer"){
      S.layer++;
      log(`⚡ 冲过小劫，突破至 <b>${GX.REALMS[S.realmIdx].name}期 ${S.layer} 层</b>！`,"good");
    }else{
      S.realmIdx++;S.layer=0;
      const cap=GX.REALMS[S.realmIdx].life;
      S.life=Math.max(S.life,cap*0.6);
      log(`🌩️ 渡过大天劫！境界跃迁至 <b>${GX.REALMS[S.realmIdx].name}期</b>，寿元重铸至 ${cap*0.6|0} 年`,"good");
    }
    fxPulse();
  }else{
    S.cult=Math.floor(S.cult*0.7);
    S.buffs.shock=Math.max(S.buffs.shock,20);
    log("💥 劫雷反噬！三成修为散逸，重伤 20 秒…","bad");
    if(info.kind==="realm")setTimeout(openEncounter,1200); // 天劫失败引动异象→奇遇
  }
  render();
}

/* ---- 通用选择面板（奇遇 / 天劫 共用 #encBox）---- */
function openChoice(title,text,opts){
  if(encounterOpen)return false;
  const box=$("encBox");
  if(!box)return false;
  encounterOpen=true;
  box.innerHTML=`
    <div class="enc-title">${title}</div>
    <div class="enc-text">${text}</div>
    <div class="enc-opts"></div>`;
  box.hidden=false;
  const optBox=box.querySelector(".enc-opts");
  opts.forEach(o=>{
    const b=document.createElement("button");
    b.className="btn-sm enc-btn";
    b.innerHTML=o.label+(o.detail?`<small>${o.detail}</small>`:"");
    if(o.disabled)b.disabled=true;
    b.onclick=()=>{if(b.disabled)return;o.act()};
    optBox.appendChild(b);
  });
  return true;
}

/* ---- 奇遇（文字选择）---- */
function pickEncounter(){
  const pool=GX.ENCOUNTERS.filter(e=>S.realmIdx>=e.minRealm);
  const total=pool.reduce((s,e)=>s+e.weight,0);
  let r=Math.random()*total;
  for(const e of pool){
    r-=e.weight;
    if(r<=0)return e;
  }
  return pool[0];
}
function openEncounter(){
  if(encounterOpen)return;
  const enc=pickEncounter();
  S.encN++;
  markSeen("encs",enc.id,enc.title);
  const opts=enc.options().map(o=>({label:o.label,detail:o.detail,act:()=>{
    const res=o.act();
    log(`📜 ${enc.title}：${res}`,res.includes("-")||res.includes("伤")?"bad":"good");
    closeEncounter();
  }}));
  openChoice(`📜 奇遇 · ${enc.title}`,enc.text,opts);
}
function closeEncounter(){
  encounterOpen=false;tribOpen=false;tribOpts=[];
  const box=$("encBox");
  if(box){box.hidden=true;box.innerHTML=""}
}

/* ---- 天劫（渡劫期九劫 + 仙界每境三场，文字选择三渡法）---- */
function currentTri(){
  if(S.realmIdx===GX.TRIB_REALM)
    return{tri:GX.TRIBS[S.layer],final:S.layer>=GX.REALMS[GX.TRIB_REALM].layers-1}; // 第 9 层 = 天道终劫
  const list=GX.XTRIBS[S.realmIdx-GX.TRIB_REALM-1];
  return{tri:list.find(t=>t.layer===S.layer)||list[0],final:isFinalTri()};
}
function openTribulation(){
  const ct=currentTri(),tri=ct.tri,final=ct.final;
  const base=tribChance("layer");
  const fc=tribFruitCost();
  const opts=[
    {label:"硬渡天劫",detail:`成功率 ${Math.round(Math.min(0.98,base+0.08)*100)}%`,act:()=>{
      const ok=Math.random()<Math.min(0.98,base+0.08);
      settleTrib(ok,{hard:true});
    }},
    {label:"借道果引渡",detail:`耗 ${fc} 道果 · 必成`,disabled:S.daoFruit<fc,act:()=>{
      S.daoFruit-=fc;
      settleTrib(true,{fruit:true});
    }},
    {label:"驭雷炼体",detail:`成功率 ${Math.round(Math.max(0.30,base-0.08)*100)}% · 成功残片+2`,act:()=>{
      const ok=Math.random()<Math.max(0.30,base-0.08);
      settleTrib(ok,{rider:ok});
    }},
  ];
  tribOpen=true;tribOpts=opts;
  const txt=final?tri.text+`（此劫连败 ${S.tribFails} 次，因果累身，成功率已降至 ${Math.round(base*100)}%）`:tri.text;
  openChoice(`⚡ ${S.realmIdx>GX.TRIB_REALM?"仙劫":"天劫"} · ${tri.name}`,txt,opts);
}
function settleTrib(ok,mode){
  const triName=currentTri().tri.name;
  closeEncounter();
  // 渡劫丹 / 玄丹 随劫自动燃尽（硬渡与驭雷才真正"渡"）
  if(!mode.fruit&&S.pills.dujie>0){S.pills.dujie--;log("渡劫丹自行燃尽护体…","dim")}
  if(S._xuanActive){S._xuanActive=false}
  if(ok){
    if(S.tribFails>0)log("因果既断，劫云渐散。","dim");
    S.tribFails=0;
    S.cult=Math.max(0,S.cult-layerNeed());
    S.layer++;S.breaks++;
    if(mode.rider){S.shards.fan+=2;log("驭雷炼体，雷光淬骨，残片+2","good")}
    log(`⚡ 渡${S.realmIdx>GX.TRIB_REALM?"仙":"天"}劫成功：<b>${triName}</b>，突破至 ${GX.REALMS[S.realmIdx].name}期 ${S.layer} 层`,"good");
    fxPulse();
  }else{
    S.cult=Math.floor(S.cult*0.7);
    if(mode.rider)S.cult=Math.floor(S.cult*0.9); // 驭雷反噬更重（共 -40%）
    S.buffs.shock=Math.max(S.buffs.shock,20);
    if(isFinalTri())S.tribFails++;
    log(`💥 ${mode.rider?"驭雷反噬":"劫雷轰落"}！${mode.rider?"修为 -40%":"修为 -30%"}，重伤 20 秒${S.tribFails>0?`，${currentTri().tri.name}因果累身（连败 ${S.tribFails} 次）`:""}`,"bad");
  }
  render();
}
