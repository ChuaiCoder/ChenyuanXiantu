"use strict";
/* ============ 数据层：全部数值配置 ============ */
const GX={};

GX.REALMS=[
  {name:"练气",layers:9,life:100},
  {name:"筑基",layers:9,life:200},
  {name:"金丹",layers:9,life:350},
  {name:"元婴",layers:9,life:550},
  {name:"化神",layers:9,life:800},
  {name:"炼虚",layers:9,life:1200},
  {name:"合体",layers:9,life:1800},
  {name:"大乘",layers:9,life:2800},
  {name:"渡劫",layers:9,life:4000},
  /* 仙界（2026-09-11 调长：飞升后经典仙界境界链，证道飞升为真终局） */
  {name:"真仙",layers:9,life:6000},
  {name:"玄仙",layers:9,life:10000},
  {name:"金仙",layers:9,life:16000},
  {name:"大罗",layers:9,life:24000},
];
GX.REALM_MULT=[1,3,10,32,100,320,1000,3200,10000,40000,160000,640000,2560000]; // 每境全局产出倍率
GX.LAYER_REQ=25;
GX.LAYER_GROWTH=1.15; // 境内层幂次（小境界曲线：恒定指数 1.15，9 层爬 ~3.5 倍）
/* 大境界需求基线（阶梯单调上行：新境首层需求 > 上境末层需求，边界台阶 ×1.05~2.4）。
   与 REALM_MULT（产出倍率）解耦——产出每境 2~4 倍平滑增长，需求按此阶梯台阶上行。
   基线整体已按 0.35 归一（人界各境总需求为原锯齿曲线的 35%，节奏 172→180 分档量级），
   仙界四境补成阶梯（原真仙为凹坑）。只改形状+整体档位，不引入新乘区。 */
GX.REALM_NEED=[5.4016,45.018,367.46,2675.75,17841.6,115185.7,691526.5,4.072775e6,2.92978e7,1.082193e8,3.997385e8,1.476538e9,6.20557e9];
GX.BASE_CULT=10, GX.OFFLINE_CAP=8*3600;
GX.EVENT_EVERY=90, GX.ENC_EVERY=150, GX.SECRET_CD=300; // 秘境冷却（秒）
GX.REALM_COLORS=["#9fb4d8","#8fd0a0","#d4b36a","#c78fd8","#e0a08a","#8ad0d8","#d8c08a","#e08aa0","#f0d894","#f6f0dc","#c9d8ff","#ffd88a","#fff0b8"];
GX.TRIB_REALM=8; // 渡劫期下标（天劫三渡法/终劫因果都锁在这一境，与 REALMS 长度无关）

/* 功法品阶（参照鬼谷八荒：功法品阶卡境界，参悟上限随境界解锁） */
GX.GONGFA_TIERS=[
  {name:"下品",minRealm:0},
  {name:"中品",minRealm:1},
  {name:"上品",minRealm:3},
  {name:"极品",minRealm:5},
  {name:"仙品",minRealm:7},
  {name:"玄仙",minRealm:9},
  {name:"神品",minRealm:11},
];

/* 洞府建筑（含新增炼器台） */
GX.BLDS=[
  {id:"zhen", icon:"🌀", name:"聚灵阵", base:15,   grow:1.55, desc:lv=>`自动修为 +${fmt(2*lv)} /秒`, cost:lv=>Math.ceil(15*Math.pow(1.55,lv))},
  {id:"mine", icon:"⛏️", name:"灵石矿", base:50,   grow:1.6,  desc:lv=>`自动灵石 +${fmt(1.5*lv)} /秒`, cost:lv=>Math.ceil(50*Math.pow(1.6,lv))},
  {id:"beast",icon:"🐉", name:"灵兽",   base:500,  grow:2.0,  desc:lv=>`全产出 +${Math.round(10*lv)}%`, cost:lv=>Math.ceil(500*Math.pow(2,lv))},
  {id:"furn", icon:"🔥", name:"丹房",   base:1000, grow:1.9,  desc:lv=>`每60秒自动炼1粒聚灵丹`, cost:lv=>Math.ceil(1000*Math.pow(1.9,lv))},
  {id:"forge",icon:"🔨", name:"炼器台", base:200,  grow:1.8,  desc:lv=>lv===0?"建成可炼凡品法宝":lv===1?"可炼凡品（升级解锁灵品）":lv===2?"可炼灵品（升级解锁玄品）":lv===3?"可炼玄品（升级解锁仙品）":"可炼仙品法宝", cost:lv=>Math.ceil(200*Math.pow(1.8,lv))},
  {id:"altar", icon:"🏮", name:"道坛",   base:3000, grow:1.9,  desc:lv=>lv===0?"建成：燃烧灵石凝练修为（灵石充足时自动，需先有灵石矿）":`每秒燃灵石 0.2×矿产×lv 凝同量修为`, cost:lv=>Math.ceil(3000*Math.pow(1.9,lv))},
];

/* 仙丹：花费=cost×1.8^境界（itemTier，境界越高丹价越重）；寿元丹效果随境界抬升（lifePillGain） */
GX.PILLS={
  juli:   {name:"聚灵丹", icon:"🔮", cost:20,  desc:"修为 +本层需求15%"},
  huichun:{name:"回春丹", icon:"💊", cost:35,  desc:()=>"寿元 +" + lifePillGain() + " 年（随境界提升）"},
  xuan:   {name:"玄丹",   icon:"🌫️", cost:150, desc:"下次渡劫成功率 +15%"},
  dujie:  {name:"渡劫丹", icon:"⚡", cost:80,  desc:"渡劫成功率 +20%（自动消耗）"},
  yanshou:{name:"延寿丹", icon:"🌸", cost:300, desc:()=>"寿元上限 +" + lifePillGain()*4 + " 年（随境界提升）"},
};

/* 灵根：转世二选一（首世随机）。w=权重 */
GX.ROOTS={
  jin:    {name:"金灵根", icon:"⚔️", w:14, desc:"残片掉率+50%，炼器花费-10%"},
  mu:     {name:"木灵根", icon:"🌿", w:14, desc:"灵兽蛋掉率+50%"},
  shui:   {name:"水灵根", icon:"💧", w:14, desc:"寿元上限+20%"},
  huo:    {name:"火灵根", icon:"🔥", w:14, desc:"丹药花费-30%"},
  tu:     {name:"土灵根", icon:"⛰️", w:14, desc:"洞府建设花费-15%"},
  lei:    {name:"雷灵根", icon:"⚡", w:12, desc:"修炼产出+35%"},
  feng:   {name:"风灵根", icon:"🌪️", w:12, desc:"机缘掉率+30%"},
  yinyang:{name:"阴阳灵根",icon:"☯️", w:4,  desc:"渡劫成功率+10%"},
  tiandao:{name:"天道灵根",icon:"🌌", w:2,  desc:"机缘掉率+40%，灵石数量×2"},
};

/* 法宝：炼器台炼造即装备（替换旧法宝，旧品折算60%灵石）；q4 仙品需炼器台Lv4、耗玄品残片 */
GX.TREASURES=[
  {q:1, name:"凡品", shard:5,  fx:{wu:8,  ju:15, yuan:3}},
  {q:2, name:"灵品", shard:12, fx:{wu:15, ju:25, yuan:5}, shardKey:"ling"},
  {q:3, name:"玄品", shard:30, fx:{wu:25, ju:40, yuan:8}, shardKey:"xuan"},
  {q:4, name:"仙品", shard:15, fx:{wu:40, ju:65, yuan:12}, shardKey:"di"},
];
GX.TREASURE_TYPES={
  wu:  {name:"护体",  desc:q=>`渡劫成功率 +${GX.TREASURES[q-1].fx.wu}%`},
  ju:  {name:"聚灵塔",desc:q=>`修为产出 +${GX.TREASURES[q-1].fx.ju}%`},
  yuan:{name:"缘钟",  desc:q=>`机缘掉率 +${GX.TREASURES[q-1].fx.yuan}%`},
};

/* 法宝祭炼：耗灵石+凡品残片给当前法宝加词条；重炼时按级 30% 概率继承。
   每词条 3 级封顶；效果锚定：护体=渡劫+3%/级、聚灵=产出+4%/级、缘钟=掉率+1%/级 */
GX.REFINE_WORDS={
  huxi:  {name:"护体诀", desc:lv=>`渡劫成功率 +${lv*3}%`},
  juling:{name:"聚灵诀", desc:lv=>`修为产出 +${lv*4}%`},
  yuan:  {name:"缘引诀", desc:lv=>`机缘掉率 +${lv*1}%`},
};

/* 灵兽蛋（P2：放生换灵石；P3 再做孵化升星） */
GX.EGGS={
  fan:  {name:"凡品", price:30},
  ling: {name:"灵品", price:100},
  xuan: {name:"玄品", price:400},
  di:   {name:"地品", price:1500},
};

/* 灵兽蛋孵化升星：孵化得灵兽，每星 +2% 全产出（stars=星级上限） */
GX.BEASTS={fan:{name:"青羽雀",stars:1},ling:{name:"赤尾狐",stars:3},xuan:{name:"玄武犊",stars:5},di:{name:"白泽",stars:5}};

/* 成就（bus 事件 + tick 轮询；每达成 log 一次） */
GX.ACHIEVEMENTS=[
  {id:"first_break",  name:"初窥门径", desc:"完成首次突破",   fx:"全产出 +5%", check:st=>st.breaks>0},
  {id:"zhuji",        name:"筑基有成", desc:"突破至筑基期",     fx:"全产出 +5%", check:st=>st.realmIdx>=1},
  {id:"jindan",       name:"丹成雷动", desc:"突破至金丹期",     fx:"全产出 +8%", check:st=>st.realmIdx>=2},
  {id:"yuanxing",     name:"元婴出窍", desc:"突破至元婴期",     fx:"全产出 +8%", check:st=>st.realmIdx>=3},
  {id:"click_1000",   name:"勤修不辍", desc:"累计修炼 1000 次", fx:"全产出 +5%", check:st=>st.clicks>=1000},
  {id:"forge_3",      name:"百炼成器", desc:"炼造 3 件法宝",    fx:"全产出 +5%", check:st=>st.forgeN>=3},
  {id:"reincarnate_1",name:"轮回渡厄", desc:"完成首次转世",     fx:"全产出 +8%", check:st=>st.times>=1},
  {id:"eggs_10",      name:"灵兽缘",   desc:"累计获得 10 枚灵兽蛋", fx:"全产出 +5%", check:st=>st.eggsGot>=10},
  {id:"encounter_10", name:"行过千帆", desc:"经历 10 次奇遇",   fx:"全产出 +5%", check:st=>st.encN>=10},
  {id:"xian",         name:"飞升真仙", desc:"渡劫圆满，飞升仙界", fx:"全产出 +8%", check:st=>st.realmIdx>=9},
  {id:"jinxian",      name:"金身不灭", desc:"步入金仙境",         fx:"全产出 +8%", check:st=>st.realmIdx>=11},
  {id:"daluozheng",   name:"证道飞升", desc:"大罗圆满，证道飞升", fx:"全产出 +10%", check:st=>st.realmIdx>=13},
  {id:"tao_first",    name:"讨伐初血", desc:"讨伐首妖",           fx:"全产出 +3%", check:st=>(st.taoKills||0)>=1},
  {id:"tao_boss",     name:"斩妖主",   desc:"讨伐五感妖主",       fx:"全产出 +5%", check:st=>(st.taoBoss||0)>=1},
];

/* 转世商店（道果 = 跨世纯货币，无被动加成；转世界面购买，入世生效）
   repeat=false 的商品每世限领一次（shopBought 记录） */
GX.SHOP=[
  {id:"reroll",   name:"道缘重抽",   desc:"本世灵根重抽 +1 次",                        cost:5,  repeat:true},
  {id:"provision",name:"出世资粮",   desc:"起始灵石+2500、修为+1000（随世数上涨）",     cost:10, repeat:true},
  {id:"pills",    name:"丹药包",     desc:"渡劫丹×1、聚灵丹×2",                        cost:8,  repeat:false},
  {id:"shards",   name:"残片包",     desc:"凡品残片 ×10（炼器材料）",                  cost:8,  repeat:false},
  {id:"egg",      name:"玄品灵兽蛋", desc:"玄品灵兽蛋 ×1（开局即有孵化材料）",          cost:12, repeat:false},
  {id:"prestige", name:"道行兑换",   desc:"道行 +1（永久全产出 +3%）",                 cost:20, repeat:true},
  {id:"tribbless",name:"天劫庇佑",   desc:"本世渡劫成功率 +12%",                       cost:25, repeat:false},
  {id:"daoheart", name:"道心供奉",   desc:"起始道心 +5（全产出 +10%）",                cost:30, repeat:false},
  {id:"dharma",   name:"先天法宝",   desc:"起始装备灵品法宝，并预铭 1 个词条",          cost:30, repeat:false},
  {id:"constitution",name:"先天之体", desc:"随机觉醒一种先天之体（五种选一，每世重铸）", cost:40, repeat:false},
];

/* 先天之体（转世商店 40 道果随机觉醒一种；每世一次，转世重铸） */
GX.CONSTITUTIONS=[
  {id:"leiti",  name:"雷淬之体", desc:"修炼产出 +30%"},
  {id:"yangti", name:"阳寿之体", desc:"寿元上限 +25%"},
  {id:"danti",  name:"万法之体", desc:"渡劫成功率 +10%"},
  {id:"lingti", name:"灵攫之体", desc:"灵石产出 +50%"},
  {id:"yuanti", name:"本源之体", desc:"机缘掉率 +25%"},
];

/* 讨伐地图（独立页签：5 节点顺序解锁，节点兽按当前境界实时生成；每世重置） */
GX.TAO_MAP=[
  {id:1, name:"废 墟", icon:"🦇", beast:"洞窟妖蝠",  desc:"洞府外的荒墟低阶妖兽出没"},
  {id:2, name:"雾 谷", icon:"🐺", beast:"雾瞳妖狼",  desc:"谷中终年雾锁，夜有狼嚎"},
  {id:3, name:"古 刹", icon:"🐍", beast:"木灵妖蟒",  desc:"废派古刹，百年灵藤盘于残殿"},
  {id:4, name:"裂 崖", icon:"🐯", beast:"裂崖雷豹",  desc:"崖壁有雷纹，石缝中兽吼如雷"},
  {id:5, name:"妖 主 巢", icon:"👹", beast:"五感妖主", desc:"妖主巢穴，其气息已压山数里（首领战）"},
];

/* 天劫（渡劫期专属：每层一种，文字选择三渡法） */
GX.TRIBS=[
  {name:"九曜雷劫", text:"九重天阙，九曜星君执鞭而下。雷光如瀑，落你头顶，威压如山。"},
  {name:"罡风劫", text:"万里罡风自九天卷落，割衣裂石。你若立得住，便过了一关。"},
  {name:"业火劫", text:"无明业火自地底燃起，焚的不是肉身，是你半生贪嗔。"},
  {name:"心魔劫", text:"四下无人，唯你与心中那个声音对坐。它说：放下吧，做回凡人。"},
  {name:"幻水劫", text:"一池幻水漫过洞府，镜中见自己——是仙，是魔，还是当年那个少年？"},
  {name:"尘缘劫", text:"红尘万丈化作锁链缠来。最断不了的不是天劫，是这一缕尘缘。"},
  {name:"寂灭劫", text:"天地归于死寂，灵气断绝。唯有道心不昧者，方能见一线生机。"},
  {name:"大乘金虹", text:"金虹贯日，此劫已近大乘之门。过此，便是人间至境。"},
  {name:"天道终劫", text:"天道本身化作一道目光，俯瞰着你。「尔可证道？」——此劫连败则因果累身。"},
];

/* 秘境（每境界解锁一个；3 回合文字抉择 + 终局结算；cd 300 秒） */
GX.SECRETS=[
  {id:"yujing", name:"玉池秘境", minRealm:0, desc:"灵气玉池自山石间渗出，润物无声"},
  {id:"leixing",name:"雷音崖",   minRealm:3, desc:"崖上雷音滚滚，淬体炼道"},
  {id:"yuanhui",name:"上古道墟", minRealm:5, desc:"上古修士遗墟，道韵未散"},
  {id:"xinghe", name:"星河界",   minRealm:7, desc:"星光沉入尘世，道纹通天"},
  {id:"xianyuan",name:"仙垣遗迹", minRealm:9, desc:"人界劫雷淬出的仙光沉入界底，真灵可与之共鸣"},
  {id:"luohai", name:"大罗星海", minRealm:12, desc:"万星如海，一念可贯过去现在未来三际"},
];

/* 仙界劫（飞升后每境 3 场，锁在第 2/5/8 层；第 8 层为本境大劫，连败累因果，同天道终劫机制） */
GX.XTRIBS=[
  [ // 真仙
    {layer:2,name:"天门劫",text:"仙门之前，天官亲执仙籍。真灵不纯者，先过天门一雷。"},
    {layer:5,name:"星河劫",text:"天河倒卷，星辉贯体。仙家星命，自此第一转。"},
    {layer:8,name:"真灵大劫",text:"你前世的真灵自识海深处浮出，与今生对坐。过此一劫，方敢言玄仙。"},
  ],
  [ // 玄仙
    {layer:2,name:"玄道劫",text:"玄道无形，它以你半生执念为刃，替你斩开一扇门。"},
    {layer:5,name:"因果劫",text:"人界因果凝成大河，漫过头顶。因果越轻，渡路越宽。"},
    {layer:8,name:"玄仙大劫",text:"天雷与因果交织，仙门审判只有一次。败，则因果累身。"},
  ],
  [ // 金仙
    {layer:2,name:"金身劫",text:"一缕太阳光直贯仙体，试你的骨血能否承载此金。"},
    {layer:5,name:"灾劫",text:"天机降下一场大灾——不是雷，是万灵目光。目光之下，道心不能乱。"},
    {layer:8,name:"金仙大劫",text:"万载金雷聚为一击。扛过此击，你便不再是人界之人。"},
  ],
  [ // 大罗
    {layer:2,name:"大罗劫",text:"过去现在未来，三际同响。你的一念，被天道摊开晾晒。"},
    {layer:5,name:"万劫",text:"万劫连环，雷中有雷，劫中有劫。这是仙途最后一场人间的考校。"},
    {layer:8,name:"证道大劫",text:"天道亲自现身：「尔可证道？」——大劫连败则因果累身，扛过即证道飞升。"},
  ],
];

/* 秘境场景（随机抽取，3 回合；act 内奖励锚定 mineRate/cultPerClick；minRealm=境界门槛） */
GX.SECRET_EVENTS=[
  {id:"beast",minRealm:0,text:"岩影间伏着一头灵兽，眼中凶光未褪。",options:()=>[
    {label:"出手迎战",detail:"胜 50%：灵石（随境界抬升）；败：重伤 15 秒",act(){
      if(Math.random()<0.5){const n=Math.ceil(Math.max(40,mineRate()*40,30*itemTier())*(1+Math.random()));S.spirit+=n;return `击退灵兽，灵石 +${fmt(n)}`}
      S.buffs.shock=Math.max(S.buffs.shock,15);S.cult*=0.8;
      return "负伤退走，重伤 15 秒，修为 -20%"}},
    {label:"且战且退",detail:"灵石 -5%",act(){
      S.spirit*=0.95;return "丢下部分灵石，狼狈脱身"}},
  ]},
  {id:"pill",minRealm:0,text:"石壁间露出一处半塌的丹窟，药香犹存。",options:()=>[
    {label:"探窟取丹",detail:"25% 大赏 / 40% 空手 / 35% 被困",act(){
      const r=Math.random();
      if(r<0.25){S.pills.dujie++;S.shards.fan+=2;return "丹窟大赏：渡劫丹 ×1、残片 ×2"}
      if(r<0.65)return "窟中空空如也，丹早已被人取走";
      S.buffs.shock=Math.max(S.buffs.shock,10);
      return "触发丹窟禁制，轻伤退出，疗伤 10 秒"}},
    {label:"静坐参悟",detail:"修为 +20 倍点击值",act(){
      const v=Math.ceil(cultPerClick()*20);S.cult+=v;
      return `静坐参悟，修为 +${fmt(v)}`}},
  ]},
  {id:"flame",minRealm:0,text:"一缕鬼火幽幽浮动，不冷不热，只照亮道心。",options:()=>[
    {label:"引火炼道",detail:"40% 道心+1 / 60% 重伤",act(){
      if(Math.random()<0.4){S.daoHeart=(S.daoHeart||0)+1;return "鬼火入体，道心 +1，道心更明"}
      S.buffs.shock=Math.max(S.buffs.shock,15);
      return "鬼火灼心，重伤 15 秒"}},
    {label:"一吹而灭",detail:"修为 +5 倍点击值",act(){
      const v=Math.ceil(cultPerClick()*5);S.cult+=v;
      return `吹散鬼火，心境澄明，修为 +${fmt(v)}`}},
  ]},
  {id:"stele",minRealm:0,text:"一方上古道碑残存，字迹剥落，道韵犹在。",options:()=>[
    {label:"参悟碑文",detail:"修为 +30 倍点击值",act(){
      const v=Math.ceil(cultPerClick()*30);S.cult+=v;
      return `道碑真意忽明，修为 +${fmt(v)}`}},
    {label:"敬香而去",detail:"灵石 +少量（随境界抬升）",act(){
      const n=Math.ceil(Math.max(30,mineRate()*30,20*itemTier()));S.spirit+=n;
      return `得一线机缘，灵石 +${fmt(n)}`}},
  ]},
  /* 仙界场景（真仙+ 仙垣秘境 / 大罗+ 大罗星海） */
  {id:"xianqi",minRealm:9,text:"云雾之间，一泓仙气凝而不散。静坐吸纳，可养肉身——贪多则灵根震荡。",options:()=>[
    {label:"静坐吸纳",detail:"修为 +40 倍点击值",act(){
      const v=Math.ceil(cultPerClick()*40);S.cult+=v;
      return `仙气入体，真元大涨，修为 +${fmt(v)}`}},
    {label:"采撷封存",detail:"灵石 +60 倍矿产 · 25% 道心+1",act(){
      const n=Math.ceil(mineRate()*60);S.spirit+=n;
      let t=`采得仙气凝结之灵石 +${fmt(n)}`;
      if(Math.random()<0.25){S.daoHeart=(S.daoHeart||0)+1;t+="，道心 +1"}
      return t}},
  ]},
  {id:"luohai",minRealm:12,text:"星河沉入此间，一颗流星的余光，足以照见百年光阴。",options:()=>[
    {label:"凝星炼道",detail:"35% 道心+1 / 65% 重伤15秒",act(){
      if(Math.random()<0.35){S.daoHeart=(S.daoHeart||0)+1;return "星光贯顶，大道一线洞明，道心 +1"}
      S.buffs.shock=Math.max(S.buffs.shock,15);
      return "星辉过烈，灼伤神识，重伤 15 秒"}},
    {label:"御星而行",detail:"修为 +50 倍点击值",act(){
      const v=Math.ceil(cultPerClick()*50);S.cult+=v;
      return `御星光而行，过去未来皆一瞬，修为 +${fmt(v)}`}},
  ]},
];

/* 奇遇（文字选择；minRealm=境界门槛，weight=权重） */
GX.ENCOUNTERS=[
  {id:"laozhe", minRealm:0, weight:30, title:"白须老者",
   text:"洞府外，一位白须老者倚杖而立：「小友道缘不薄，老朽留下一份薄礼，权作结缘。」",
   options:()=>[
     {label:"接受馈赠", detail:"获得随机仙丹一枚", act(){
        const k=["juli","huichun","dujie","xuan"][Math.random()*4|0];
        S.pills[k]++;
        return `得 ${GX.PILLS[k].icon}${GX.PILLS[k].name} ×1`;}},
     {label:"婉言谢绝", detail:"寿元 +2 年", act(){
        S.life+=2;return "老者颔首而去，心境平和，寿元 +2 年";}},
   ]},
  {id:"youshou", minRealm:0, weight:25, title:"妖兽拦路",
   text:"林间一道黑影扑出，拦在你身前——一头低阶妖兽，眼中凶光未褪。",
   options:()=>[
       {label:"出手迎战", detail:"胜 50%：灵石+残片（随境界抬升）；败：重伤15秒-20%修为", act(){
          const sp=Math.ceil(Math.max(30,mineRate()*30,30*itemTier()));
          if(Math.random()<0.5){S.spirit+=sp;S.shards.fan++;return `击退妖兽！灵石 +${fmt(sp)}、残片×1`}
          S.buffs.shock=Math.max(S.buffs.shock,15);S.cult*=0.8;
          return "负伤退走，重伤 15 秒，修为 -20%";}},
       {label:"且战且退", detail:"损失 5% 灵石", act(){
          S.spirit*=0.95;return "丢下部分灵石，狼狈脱身";}},
   ]},
  {id:"heimi", minRealm:0, weight:15, title:"无面行商",
   text:"夜色里，一个无面行商支起摊子：「有缘人，好货不贵。」",
   options:()=>{
     const c1=Math.ceil(Math.max(150,mineRate()*60,120*itemTier())), c2=Math.ceil(Math.max(400,mineRate()*160,320*itemTier()));
     return [
       {label:`购残片 ×5`, detail:`${fmt(c1)} 灵石`, act(){
          if(S.spirit>=c1){S.spirit-=c1;S.shards.fan+=5;return "购得凡品残片 ×5"}
          return "灵石不足，行商收起摊位";}},
       {label:"购法宝一件", detail:`${fmt(c2)} 灵石（随机品型）`, act(){
          if(S.spirit>=c2){S.spirit-=c2;forgeTreasure(1,true);return "购得一件凡品法宝"}
          return "灵石不足，行商收起摊位";}},
       {label:"告辞离开", detail:"", act(){return "你拱手离去，夜风拂面";}},
     ];}},
  {id:"tongmen", minRealm:1, weight:15, title:"同门切磋",
   text:"一位散修拦路：「久闻道友道行精进，不如今夜切磋一场，输赢各付彩头。」",
   options:()=>{
     const win=Math.min(0.8,0.40+S.realmIdx*0.08);
     return [
       {label:`应战（胜率${Math.round(win*100)}%）`, detail:"胜：灵品残片×2+随机丹；败：修为-10%", act(){
          if(Math.random()<win){S.shards.ling+=2;
            const k=["juli","huichun","dujie"][Math.random()*3|0];S.pills[k]++;
            return `切磋胜出！灵品残片×2、得 ${GX.PILLS[k].name} ×1`}
          S.cult*=0.9;return "略逊一筹，修为 -10%，胜者不骄";}},
       {label:"改日再战", detail:"", act(){return "你拱手让过，对方一笑而去";}},
     ];}},
  {id:"daoheart", minRealm:6, weight:20, title:"天音问道",
   text:"云外忽传一道钟鸣，声如洪钟又似私语：「尔之道心，尚未圆满。道可道，非常道。」",
   options:()=>[
     {label:"听道片刻", detail:"道心 +1：全产出 +2%（永久，至多 +30%）", act(){
        S.daoHeart=(S.daoHeart||0)+1;
        return `聆听天音，道心愈发坚凝（道心 ${S.daoHeart}，全产出 +${Math.min(30,S.daoHeart*2)}%）`;}},
     {label:"守心默修", detail:"修为 +20 倍点击值", act(){
        const v=Math.ceil(cultPerClick()*20);S.cult+=v;
        return `守心静修，不为所动，修为 +${fmt(v)}`;}},
   ]},
  {id:"mijing", minRealm:2, weight:15, title:"秘境残窟",
   text:"山壁间忽现一道裂口，内传微光——竟是一处上古秘境残窟，机缘与凶险并存。",
   options:()=>[
     {label:"深入探取", detail:"25%大赏 / 35%重伤 / 40%空手", act(){
        const r=Math.random();
        if(r<0.25){S.pills.dujie++;S.shards.xuan+=2;return "秘境大赏：渡劫丹×1、玄品残片×2！"}
        if(r<0.6){return "窟中空空如也，唯余尘埃"}
        S.buffs.shock=Math.max(S.buffs.shock,10);
        return "触发残窟禁制，轻伤退出，疗伤 10 秒";}},
     {label:"封洞作罢", detail:"", act(){return "你以灵力封住裂口，来日再探";}},
   ]},
  {id:"xianmen", minRealm:9, weight:18, title:"仙门引路",
   text:"一道虹桥自云外垂落，尽头有仙官执册而立：「新晋真仙，仙籍待录。录名者，得天庭赐丹。」",
   options:()=>[
     {label:"录名受丹", detail:"得渡劫丹×1、聚灵丹×2", act(){
        S.pills.dujie++;S.pills.juli+=2;
        return "仙籍录名，赐渡劫丹×1、聚灵丹×2";}},
     {label:"不录逍遥", detail:"修为 +15 倍点击值", act(){
        const v=Math.ceil(cultPerClick()*15);S.cult+=v;
        return `你不愿受仙籍所缚，虹桥自散，修为 +${fmt(v)}`;}},
   ]},
  {id:"sanshi", minRealm:12, weight:20, title:"三际问道",
   text:"时间在此处摊开成一幅长卷：你的过去、现在、未来并排而坐。天道之音响起：「三际同问，道在何际？」",
   options:()=>[
     {label:"答：在当下", detail:"道心 +1：全产出 +2%（上限 +30%）", act(){
        S.daoHeart=(S.daoHeart||0)+1;
        return `三卷同亮，长卷徐徐收起（道心 ${S.daoHeart}，全产出 +${Math.min(30,S.daoHeart*2)}%）`;}},
     {label:"不答，只修行", detail:"修为 +25 倍点击值", act(){
        const v=Math.ceil(cultPerClick()*25);S.cult+=v;
        return `你闭目不答，三卷自燃为光，修为 +${fmt(v)}`;}},
   ]},
];
