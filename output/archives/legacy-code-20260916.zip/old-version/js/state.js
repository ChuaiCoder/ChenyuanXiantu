"use strict";
/* ============ 状态层 ============ */
function freshState(){
  return {
    v:2, name:"无名道修",
    realmIdx:0, layer:0,
    cult:0, spirit:0, life:1, lifeBonus:0,
    gongfaLv:1,
    root:"jin",                       // 灵根 id
    bld:{zhen:0,mine:0,beast:0,furn:0,forge:0,altar:0},
    pills:{juli:0,huichun:0,xuan:0,dujie:0,yanshou:0},
    shards:{fan:0,ling:0,xuan:0,di:0},      // 法宝残片（di=仙品用）
    treasure:null,                     // 已装备法宝 {q,type}
    eggs:{fan:0,ling:0,xuan:0,di:0},   // 灵兽蛋
    beasts:{fan:0,ling:0,xuan:0,di:0}, // 已孵化灵兽（升星）
    buffs:{tide:0,shock:0},
    secretCd:0,                          // 秘境冷却（秒）
    constitution:null,                   // 先天之体（转世商店，每世重铸）
    tribBless:false,                     // 天劫庇佑（转世商店，本世渡劫 +12%）
    prestige:0, times:0,
    daoHeart:0,                        // 道心（天音问道，全产出 +2%/层，上限 +30%）
    daoFruit:0,                        // 道果（跨世保留；仅在轮回时按 lifeFruit() 结算结出，引渡/商店货币）
    tribFails:0,                       // 天道终劫连败次数（因果递减）
    seen:{roots:{},treasures:{},beasts:{},encs:{},tao:{}}, // 道果图鉴（跨世保留，仅 +0.5%/项）
    med:0,                             // 闭关剩余时间（秒）
    _pend:{},                          // 转世商店暂存（入世/重载时结算）
    breaks:0, clicks:0, forgeN:0,      // 成就计数
    eggsGot:0, encN:0,
    taoMax:1,                          // 讨伐地图已解锁最高节点（1~5，每世重置）
    taoKills:0, taoBoss:0,             // 讨伐计数（成就用）
    achieved:{},                       // 已达成成就 id
    lastTs:Date.now(),
  };
}
/* 图鉴点亮数（灵根9+法宝12+灵兽4+奇遇8+讨伐妖5=38） */
function codexCount(){
  const s=S.seen||{};
  return ["roots","treasures","beasts","encs","tao"].reduce((n,k)=>n+Object.keys(s[k]||{}).length,0);
}

/* 灵根随机：k 个候选（转世二选一 / 首世随机） */
function rollRoots(k){
  const pool=Object.keys(GX.ROOTS);
  let total=pool.reduce((s,id)=>s+GX.ROOTS[id].w,0);
  const picked=[];
  for(let i=0;i<Math.min(k,pool.length);i++){
    let r=Math.random()*total;
    for(const id of pool){
      if(picked.includes(id))continue;
      r-=GX.ROOTS[id].w;
      if(r<=0){picked.push(id);total-=GX.ROOTS[id].w;break}
    }
    if(picked.length<=i){ // 兜底：随机数溢出时补一个未选项
      const left=pool.find(id=>!picked.includes(id));
      if(left){picked.push(left);total-=GX.ROOTS[left].w}
    }
  }
  return picked;
}

/* ============ 核心数值 ============ */
function realmMult(){return GX.REALM_MULT[S.realmIdx]}
function globalMult(){
  let m=realmMult()*(1+0.10*S.bld.beast)*(1+0.03*S.prestige);
  if(S.root==="lei")m*=1.35;                                    // 雷灵根
  if(S.treasure&&S.treasure.type==="ju")m*=1+GX.TREASURES[S.treasure.q-1].fx.ju/100; // 聚灵塔
  if(S.daoHeart)m*=1+Math.min(0.30,S.daoHeart*0.02);            // 道心
  if(S.constitution==="leiti")m*=1.30;                          // 先天之体·雷淬之体
  m*=1+wordLevel("juling")*0.04;                                // 法宝祭炼·聚灵诀
  m*=1+codexCount()*0.005;                                      // 道果图鉴（每项+0.5%）
  m*=1+Math.min(0.10,Object.values(S.beasts||{}).reduce((s,n)=>s+n,0)*0.02); // 灵兽升星
  for(const a of GX.ACHIEVEMENTS)                               // 成就
    if(S.achieved[a.id])m*=(1+parseInt(a.fx.match(/\d+/)[0],10)/100);
  return m;
}
function cultPerClick(){return GX.BASE_CULT*Math.pow(1.8,S.gongfaLv-1)*globalMult()}
function zhenRate(){return 2*S.bld.zhen*globalMult()}
function mineRate(){
  let r=1.5*S.bld.mine*(1+0.15*(S.gongfaLv-1))*realmMult();
  if(S.constitution==="lingti")r*=1.5;                          // 先天之体·灵攫之体
  return r;
}
function lifeCap(){
  let cap=GX.REALMS[S.realmIdx].life+(S.lifeBonus||0);
  if(S.root==="shui")cap=Math.round(cap*1.2);
  if(S.constitution==="yangti")cap=Math.round(cap*1.25);        // 先天之体·阳寿之体
  return cap;
}
function layerNeed(){
  // 大境界阶梯（REALM_NEED）× 小境界幂次（LAYER_GROWTH^层）；与产出倍率 REALM_MULT 解耦
  return Math.ceil(GX.LAYER_REQ*GX.REALM_NEED[S.realmIdx]*Math.pow(GX.LAYER_GROWTH,S.layer));
}
function isTopLayer(){return S.layer>=GX.REALMS[S.realmIdx].layers}
function isFinalRealm(){return S.realmIdx===GX.REALMS.length-1}
/* 本层是否为「本境大劫」（渡劫期=第 9 层·天道终劫；仙界=第 9 层·证道/各境大劫）：连败累因果 */
function isFinalTri(){
  if(S.realmIdx===GX.TRIB_REALM)return S.layer>=GX.REALMS[GX.TRIB_REALM].layers-1;
  if(S.realmIdx>GX.TRIB_REALM)return S.layer===GX.REALMS[S.realmIdx].layers-1;
  return false;
}
/* 仙界特殊劫所在层（真仙/玄仙/金仙/大罗：第 3/6/9 层弹三渡法面板） */
function isXianTriLayer(){
  if(S.realmIdx<=GX.TRIB_REALM)return false;
  return GX.XTRIBS[S.realmIdx-GX.TRIB_REALM-1].some(t=>t.layer===S.layer);
}
function prestigeGain(){
  if(isFinalRealm()&&isTopLayer())return 50+S.layer;
  if(S.times>=1)return 5+S.realmIdx*2+S.layer;
  return 0;
}
/* 道果结出（仅在轮回时结算一生，参照小说设定：道果为后期概念，元婴以下未凝）：
   元婴 3 → 每境 +3 → 渡劫圆满 21 → 大罗圆满 33+15 加赠=48。一生中途道果只减（引渡/商店） */
function lifeFruit(){
  if(S.realmIdx<3)return 0; // 元婴以下，道果未凝
  let f=(S.realmIdx-2)*3+Math.floor(S.layer/3);
  if(isFinalRealm()&&isTopLayer())f+=15; // 证道圆满加赠
  return f;
}
/* 功法参悟上限 = 已解锁品阶级数（1..7，第 N 重即第 N 品） */
function gongfaMaxLv(){
  let m=0;
  for(const t of GX.GONGFA_TIERS)if(S.realmIdx>=t.minRealm)m++;
  return Math.max(1,m);
}
/* 图鉴总项数（灵根+法宝+灵兽+奇遇+讨伐妖） */
function codexTotal(){
  return Object.keys(GX.ROOTS).length+GX.TREASURES.length*Object.keys(GX.TREASURE_TYPES).length+Object.keys(GX.BEASTS).length+GX.ENCOUNTERS.length+GX.TAO_MAP.length;
}

/* 物品境界难度：丹药/功法/蛋/奇遇定值等花费与收益按 1.8^境界 阶梯抬升（独立于产出 REALM_MULT，
   境界越高丹药不再是零头；练气期系数=1，早期数值不变） */
function itemTier(){return Math.pow(1.8,S.realmIdx)}
/* 寿元丹效果抬升（回春=1 倍 / 延寿=4 倍） */
function lifePillGain(){return Math.ceil(5*itemTier())}
/* 灵兽蛋放生价（随境界抬升） */
function eggPrice(k){return Math.ceil(GX.EGGS[k].price*itemTier())}
/* 功法参悟花费（1.6^重 × 境界难度） */
function gongfaCost(){return Math.ceil(100*Math.pow(1.6,S.gongfaLv-1)*itemTier())}

/* 花费（含灵根折扣） */
function bldCost(id){
  const b=GX.BLDS.find(x=>x.id===id);
  let c=b.cost(S.bld[id]);
  if(S.root==="tu")c=Math.ceil(c*0.85);
  return c;
}
function pillCost(k){
  let c=Math.ceil(GX.PILLS[k].cost*itemTier());
  if(S.root==="huo")c=Math.ceil(c*0.7);
  return c;
}
/* 残片品级阶梯：1品耗凡品/2品耗灵品/3品耗玄品/4品耗地品（金根-10%） */
function shardCost(q){
  const t=GX.TREASURES[q-1];
  const key=t.shardKey||"fan";
  let n=t.shard;
  if(S.root==="jin")n=Math.ceil(n*0.9);
  return{key,n};
}
/* 道坛：燃烧灵石凝练修为（灵石后期出口）；纯矿产锚定，无矿不灵（不挤早期投资） */
function altarRate(){
  if(S.bld.altar<=0)return 0;
  return mineRate()*0.2*S.bld.altar;
}
/* 祭炼：灵石锚定 mineRate（无矿时保底 200），残片按法宝品级池 */
function refineCost(){
  const sc=shardCost(S.treasure.q);
  return {
    spirit:Math.ceil(Math.max(200,mineRate()*120)),
    shardKey:sc.key,
    shard:sc.n,
  };
}
function wordLevel(id){return (S.treasure&&S.treasure.words&&S.treasure.words[id])||0}

/* ============ 讨伐战斗（数值全部锚定 cultPerClick，随境界/功法/全局乘区自然抬升） ============
   灵兽星总数（凡1/灵3/玄5/地5 上限内，与孵化升星同一资源） */
function beastStars(){
  return Object.keys(GX.BEASTS).reduce((s,k)=>s+Math.min(GX.BEASTS[k].stars,S.beasts[k]||0),0);
}
/* 战力锚（= 点击修炼力：功法×全局乘区×境界） */
function taoAtk(){return cultPerClick()}
/* 气血池（约 6 秒全力点击的量级 → 首节点一场战斗 ~30 秒回合数） */
function taoHp(){return Math.ceil(cultPerClick()*6)}
/* 减伤（小数：护体法宝 品级50%→25% + 聚灵 品级65%→~22%，cap 50%） */
function taoDefPct(){
  let d=0;
  if(S.treasure&&S.treasure.type==="wu")d+=GX.TREASURES[S.treasure.q-1].fx.wu/200;
  if(S.treasure&&S.treasure.type==="ju")d+=GX.TREASURES[S.treasure.q-1].fx.ju/300;
  return Math.min(0.5,d);
}

/* 渡劫成功率（层劫 90% / 境界劫 60%，各类加成，cap 98%） */
function tribBase(kind){return kind==="layer"?0.9:0.6}
/* 借道果引渡费用：人界 5，仙界每境 +5（劫越重，引渡越贵） */
function tribFruitCost(){return 5+Math.max(0,S.realmIdx-GX.TRIB_REALM)*5}
function tribChance(kind){
  let c=tribBase(kind);
  if(S.pills.dujie>0)c+=0.20;          // 渡劫丹（doBreak 时自动消耗）
  if(S.treasure&&S.treasure.type==="wu")c+=GX.TREASURES[S.treasure.q-1].fx.wu/100;
  c+=wordLevel("huxi")*0.03;                                    // 法宝祭炼·护体诀
  if(S._xuanActive)c+=0.15;
  if(S.root==="yinyang")c+=0.10;
  if(S.constitution==="danti")c+=0.10;                           // 先天之体·万法之体
  if(S.tribBless)c+=0.12;                                        // 天劫庇佑（转世商店）
  c=Math.min(0.98,c);
  if(kind==="layer"&&isFinalTri()){
    // 本境大劫（天道终劫/证道大劫）：连败累加因果，每败一次 -5%（下限 30%）
    c=Math.max(0.30,c-0.05*S.tribFails);
  }
  return c;
}

/* 机缘掉落概率（仅点击修炼触发） */
function dropChance(kind){
  let c={spirit:0.08,shard:0.06,egg:0.04}[kind];
  if(S.root==="feng")c*=1.30;
  if(S.root==="tiandao")c*=1.40;
  if(S.root==="jin"&&kind==="shard")c*=1.50;
  if(S.root==="mu"&&kind==="egg")c*=1.50;
  if(S.constitution==="yuanti")c*=1.25;                         // 先天之体·本源之体
  if(S.treasure&&S.treasure.type==="yuan")c+=GX.TREASURES[S.treasure.q-1].fx.yuan/100;
  c+=wordLevel("yuan")*0.01;                                    // 法宝祭炼·缘引诀
  return Math.min(0.6,c);
}
