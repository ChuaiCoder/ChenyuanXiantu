"use strict";
/* ============ 渲染层：差量渲染（renderKey 不变则整块跳过） ============
   render() 只负责按序调用块级函数；每块自持 key，未来加新块只需新函数+新 key。 */

/* ---- 周天法轮：随境界叠加纹样（realmIdx 每 +1 多一层复杂度） ---- */
const RING_CACHE={v:-1};
const G="rgba(216,180,94,";
function ringLayers(ri){
  // 每个大境界新增的纹样（1-9），越靠内层越基础
  const layers=[];
  if(ri>=1)layers.push({r:88,cls:"dash",sp:80});                 // 二层：外虚线刻度环
  if(ri>=2)layers.push({r:80,cls:"ticks",sp:-46,rot:"reverse"}); // 三层：八芒刻度环（对转）
  if(ri>=3)layers.push({r:72,cls:"orbit",sp:24});                // 四层：轨道星点
  if(ri>=4)layers.push({r:64,cls:"dots",sp:-30});                // 五层：点线环
  if(ri>=5)layers.push({r:56,cls:"seg",sp:18});                  // 六层：分段环
  if(ri>=6)layers.push({r:48,cls:"dash",sp:-60});                // 七层：细虚线环
  if(ri>=7)layers.push({r:42,cls:"ticks",sp:36});                // 八层：密刻度环
  if(ri>=8)layers.push({r:96,cls:"halo",sp:0});                  // 九层：法相金晕（最外）
  return layers;
}
function layerStyle(l,ri){
  const a=Math.min(0.55,0.22+ri*0.03); // 境界越高，纹样越亮
  const s={position:"absolute",borderRadius:"50%",animation:`spin ${l.sp}s linear infinite`};
  if(l.cls==="dash"){s.inset=(100-l.r)/2+"%";s.border=`1px dashed ${G}${a})`}
  else if(l.cls==="ticks"){
    s.inset=(100-l.r)/2+"%";s.border="none";
    s.background=`repeating-conic-gradient(${G}${a}) 0 10deg,transparent 10deg 30deg)`;
    s.webkitMask=s.mask="radial-gradient(farthest-side,transparent calc(100% - 7px),#000 calc(100% - 6px))";
    if(l.rot==="reverse")s.animationDirection="reverse";
  }else if(l.cls==="orbit"){
    s.inset=(100-l.r)/2+"%";s.border="1px solid rgba(216,180,94,.12)";
    s.background=`radial-gradient(circle at 50% 0,${G}${a+0.2}) 3px,transparent 4px)`;
  }else if(l.cls==="dots"){
    s.inset=(100-l.r)/2+"%";s.border="none";
    s.background=`radial-gradient(circle,${G}${a+0.2}) 1.5px,transparent 2px)`;
    s.backgroundSize="13% 13%";
    s.webkitMask=s.mask="radial-gradient(farthest-side,transparent calc(100% - 4px),#000 calc(100% - 3px))";
    s.animationDirection="reverse";
  }else if(l.cls==="seg"){
    s.inset=(100-l.r)/2+"%";s.border="none";
    s.background=`conic-gradient(from 20deg,${G}${a}) 0 25deg,transparent 25deg 72deg,${G}${a*0.7}) 72deg 97deg,transparent 97deg 144deg,${G}${a}) 144deg 169deg,transparent 169deg 216deg,${G}${a*0.7}) 216deg 241deg,transparent 241deg 288deg,${G}${a}) 288deg 313deg,transparent 313deg)`;
    s.webkitMask=s.mask="radial-gradient(farthest-side,transparent calc(100% - 5px),#000 calc(100% - 4px))";
  }else if(l.cls==="halo"){
    s.inset=(100-l.r)/2+"%";s.border=`1px solid ${G}0.12)`;
    s.boxShadow=`0 0 26px ${G}0.18),inset 0 0 26px ${G}0.10)`;
    s.animationName="halopulse";
    s.animationDuration="4s";
    s.animationTimingFunction="ease-in-out";
    s.animationIterationCount="infinite";
  }
  return s;
}
function refreshRing(){
  if(RING_CACHE.v===S.realmIdx)return;
  RING_CACHE.v=S.realmIdx;
  const wrap=$("coreWrap");
  wrap.querySelectorAll(".ring-layer").forEach(el=>el.remove());
  for(const l of ringLayers(S.realmIdx)){
    const d=document.createElement("div");
    d.className="ring-layer";
    const st=layerStyle(l,S.realmIdx);
    for(const k in st)d.style[k]=st[k];
    wrap.insertBefore(d,$("coreRing"));
  }
  const c=document.createElement("style");
  c.textContent="@keyframes halopulse{0%,100%{opacity:.55}50%{opacity:1}}";
  if(!document.getElementById("haloKf")){c.id="haloKf";document.head.appendChild(c)}
}

/* ---- 块：道身（法轮/修为/寿元/按钮，每 tick 轻量同步） ---- */
const coreLabelPrev={v:""};
const rootLinePrev={v:""};
const medBtnPrev={v:""};    // 闭关按钮：只在 入定/出定 切换时重建（innerHTML 每 tick 重写会令按住点击落空）
const breakBtnPrev={v:""};   // 渡劫按钮：文案/徽章变化才重建
function renderCore(){
  refreshRing();
  $("coreName").textContent=S.name;
  // 周天法轮：充能环 + 境界色
  $("coreRing").style.setProperty("--p",Math.min(100,S.cult/layerNeed()*100).toFixed(1));
  document.documentElement.style.setProperty("--realm",GX.REALM_COLORS[Math.min(S.realmIdx,GX.REALM_COLORS.length-1)]);
  const cl=isFinalRealm()&&isTopLayer()?"证道圆满":GX.REALMS[S.realmIdx].name;
  if(coreLabelPrev.v!==cl){coreLabelPrev.v=cl;$("coreLabel").textContent=cl}
  // 灵根
  const r=GX.ROOTS[S.root];
  const cS=GX.CONSTITUTIONS.find(x=>x.id===S.constitution);
  const rk=r.icon+r.name+(cS?`｜${cS.name}`:"");
  if(rootLinePrev.v!==rk){
    rootLinePrev.v=rk;
    $("rootLine").innerHTML=`${r.icon} <b>${r.name}</b> · ${r.desc}`+(cS?`<br>🧬 <b>${cS.name}</b> · ${cS.desc}`:"");
  }
  $("cultVal").textContent=fmt(S.cult);
  $("cultNeed").textContent=fmt(layerNeed());
  $("cultBar").style.width=Math.min(100,S.cult/layerNeed()*100)+"%";
  const cap=lifeCap();
  $("lifeVal").textContent=Math.floor(S.life);
  $("lifeMax").textContent=Math.floor(cap);
  $("lifeBar").style.width=Math.min(100,S.life/cap*100)+"%";
  $("lifeBar").style.background=S.life/cap<0.2?"linear-gradient(90deg,#8a3030,var(--bad))":"";
  // 修炼按钮（只更新提示文字，不重建 DOM）
  const ch=$("cultHint");
  const hv=`修为 +${fmt(cultPerClick())} · 阵产 ${fmt(zhenRate())}/秒`;
  if(ch.textContent!==hv)ch.textContent=hv;
  // 行动按钮
  const med=S.med>0;
  const hb=$("btnHerb");
  hb.disabled=!!pending.herb||med;
  $("herbT").textContent=pending.herb?fmtTime((pending.herb.t-performance.now())/1000):"15秒";
  const rb=$("btnRoam");
  rb.disabled=!!pending.roam||med;
  $("roamT").textContent=pending.roam?fmtTime((pending.roam.t-performance.now())/1000):"45秒";
  const mb=$("btnMed");
  mb.disabled=med;
  if(medBtnPrev.v!==med){ // 只在 入定/出定 切换时重建，平时只更新倒计时文本
    medBtnPrev.v=med;
    mb.innerHTML=med?`闭关出定 <span class="pill" id="medT"></span>`:`闭关入定<small>120秒 · 自动凝练修为</small>`;
  }
  if(med){const mt=$("medT");if(mt)mt.textContent=fmtTime(S.med)}
  // 秘境
  const cs=currentSecret();
  const sh=$("secretHint");
  const shv=cs?(S.secretCd>0?`冷却 ${fmtTime(S.secretCd)}`:`${cs.name} · 3回合抉择`):"尚未开启";
  if(sh.textContent!==shv)sh.textContent=shv;
  const sb=$("btnSecret");
  if(sb){sb.disabled=!cs||S.secretCd>0||med}
  $("btnCultivate").disabled=med;
  // 渡劫（文案/渡劫丹徽章变化才重建，避免每 tick 重写 innerHTML）
  const bi=breakInfo();
  const bb=$("btnBreak");
  bb.disabled=!bi.ok||med;
  bb.classList.toggle("breakable",bi.ok);
  const bp=(bi.ok?"ok":"no")+bi.txt+(S.pills.dujie>0&&bi.ok?"d":"");
  if(breakBtnPrev.v!==bp){
    breakBtnPrev.v=bp;
    bb.innerHTML=`⚡ ${bi.txt}`+(S.pills.dujie>0&&bi.ok?`<small>渡劫丹待命 +20%</small>`:"");
  }
}

/* ---- 块：仙丹（数量变化才重建；按钮可用性每 tick 同步） ---- */
function renderPills(){
  // key 含境界：丹价/寿元丹说明随 itemTier 变化，境界跳变需重建（realmIdx 稳定，不会每 tick 变）
  const key=JSON.stringify(S.pills)+"|"+S.realmIdx;
  if(key!==renderKey.pills){
    renderKey.pills=key;
    let ph="";
    for(const k in GX.PILLS){
      const p=GX.PILLS[k];
      const ds=typeof p.desc==="function"?p.desc():p.desc;
      ph+=`<div class="row">
        <div class="info"><div class="nm">${p.icon} ${p.name} <b>×${S.pills[k]}</b></div><div class="ds">${ds}</div></div>
        <button class="btn-sm" data-pill="${k}">服用</button>
        <button class="btn-sm" data-craft="${k}">炼(${fmt(pillCost(k))})</button>
      </div>`;
    }
    $("pillsBox").innerHTML=ph;
  }
  const pbox=$("pillsBox");
  for(const k in GX.PILLS){
    const u=pbox.querySelector(`[data-pill="${k}"]`),c=pbox.querySelector(`[data-craft="${k}"]`);
    if(u)u.disabled=S.pills[k]<=0;
    if(c)c.disabled=S.spirit<pillCost(k);
  }
}

/* ---- 块：洞府建筑（等级变化才重建） ---- */
function renderBld(){
  const key=JSON.stringify(S.bld);
  if(key!==renderKey.bld){
    renderKey.bld=key;
    let bh="";
    for(const b of GX.BLDS){
      const lv=S.bld[b.id],cost=bldCost(b.id);
      bh+=`<div class="row">
        <div class="info"><div class="nm">${b.icon} ${b.name} <b>Lv.${lv}</b></div>
        <div class="ds">${b.desc(lv)}</div>
        ${lv>0?`<div class="cost">下一级：${fmt(cost)} 灵石</div>`:`<div class="cost">建造：${fmt(cost)} 灵石</div>`}</div>
        <button class="btn-sm" data-bld="${b.id}">扩建</button>
      </div>`;
    }
    bh+=`<div class="row" style="border:0"><div class="info"><div class="nm">💠 灵石</div><div class="ds">当前 <b data-spiritVal style="color:var(--gold2)"></b> · 矿产 ${fmt(mineRate())}/秒</div></div></div>`;
    $("bldBox").innerHTML=bh;
  }
  const bbox=$("bldBox");
  for(const b of GX.BLDS){
    const btn=bbox.querySelector(`[data-bld="${b.id}"]`);
    if(btn)btn.disabled=S.spirit<bldCost(b.id);
  }
  const sv=bbox.querySelector("[data-spiritVal]");
  if(sv)sv.textContent=fmt(S.spirit);
}

/* ---- 块：炼器/法宝/残片 ---- */
function renderForge(){
  // key 用祭炼灵石成本+境界（随矿/品级/境界离散变化）而非灵石余额，避免每 tick 重建按钮
  const key=JSON.stringify(S.shards)+JSON.stringify(S.treasure)+"|"+S.bld.forge+"|"+S.realmIdx+"|"+Math.ceil(mineRate()*120);
  if(key!==renderKey.forge){
    renderKey.forge=key;
    let fh="";
    for(let q=1;q<=GX.TREASURES.length;q++){
      const t=GX.TREASURES[q-1];
      const need=shardCost(q);
      const locked=S.bld.forge<q;
      const shardNm={fan:"凡品",ling:"灵品",xuan:"玄品",di:"地品"}[need.key];
      fh+=`<div class="row">
        <div class="info"><div class="nm">🔨 ${t.name}法宝</div>
        <div class="ds">随机器型 · 护体/聚灵/缘钟${locked?`（需炼器台Lv${q}）`:""}</div>
        ${locked?"":`<div class="cost">${shardNm}残片 ×${need.n}</div>`}</div>
        <button class="btn-sm" data-forge="${q}" ${locked?"disabled":""}>炼造</button>
      </div>`;
    }
    const tr=S.treasure;
    if(tr){
      const tt=GX.TREASURE_TYPES[tr.type], tq=GX.TREASURES[tr.q-1];
      const wc=refineCost();
      let wl="";
      for(const id in GX.REFINE_WORDS){
        const lv=wordLevel(id);
        if(lv>0)wl+=`<span class="badge on" title="${GX.REFINE_WORDS[id].desc(lv)}">${GX.REFINE_WORDS[id].name}·${lv}</span>`;
      }
      fh+=`<div class="row" style="border:0"><div class="info"><div class="nm">本命法宝：${tq.name}${tt.name}</div>
        <div class="ds">${tt.desc(tr.q)}（重炼则熔旧折现，词条 30% 继承）</div>
        ${wl?`<div class="ds" style="margin-top:4px">${wl}</div>`:``}</div>
        <button class="btn-sm" data-refine="1">祭炼<small>${fmt(wc.spirit)}灵石+残片×${wc.shard}</small></button></div>`;
    }else{
      fh+=`<div class="row" style="border:0"><div class="info"><div class="nm">本命法宝：无</div><div class="ds">炼造即装备，可替换；成器后可祭炼加词条</div></div></div>`;
    }
    $("forgeBox").innerHTML=fh;
  }
  const fbox=$("forgeBox");
  for(let q=1;q<=GX.TREASURES.length;q++){
    const btn=fbox.querySelector(`[data-forge="${q}"]`);
    const need=shardCost(q);
    if(btn)btn.disabled=S.bld.forge<q||S.shards[need.key]<need.n;
  }
  const rb=S.treasure?fbox.querySelector("[data-refine]"):null;
  if(rb){
    const wc=refineCost();
    const full=Object.keys(GX.REFINE_WORDS).every(id=>wordLevel(id)>=3);
    rb.disabled=full||S.spirit<wc.spirit||S.shards.fan<wc.shard;
  }
}

/* ---- 块：灵兽蛋（放生/孵化）----
   key 不含灵石数：灵石每秒变会让按钮 DOM 每 tick 重建，点击易落空 */
function renderEgg(){
  const key=JSON.stringify(S.eggs)+JSON.stringify(S.beasts)+"|"+S.realmIdx;
  if(key!==renderKey.egg){
    renderKey.egg=key;
    let eh="";
    for(const k in GX.EGGS){
      const e=GX.EGGS[k];
      eh+=`<span class="egg-item">${e.name}×${S.eggs[k]}
        <button class="btn-xs" data-hatch="${k}">孵化</button>
        <button class="btn-xs" data-egg="${k}">放(${fmt(eggPrice(k))})</button></span>`;
    }
    $("eggNm").innerHTML=eh;
  }
  const ebox=$("eggNm");
  for(const k in GX.EGGS){
    const hb=ebox.querySelector(`[data-hatch="${k}"]`),rb=ebox.querySelector(`[data-egg="${k}"]`);
    if(hb)hb.disabled=S.eggs[k]<=0||S.beasts[k]>=GX.BEASTS[k].stars; // 满星后孵化无意义
    if(rb)rb.disabled=S.eggs[k]<=0;
  }
}

/* ---- 块：讨伐（墨图 5 节点 + 战斗面板）
   地图：解锁数/境界/开战节点变化才重建；行动格：开战/结束/境界跳变才重建
   （回合数/血条/按钮可用性每 tick 只改文本与宽度，避免重写 innerHTML 令点击落空） ---- */
function renderBattle(){
  const B=battle;
  const mapKey=S.taoMax+"|"+S.realmIdx+"|"+(B?B.node:0);
  if(mapKey!==renderKey.taoMap){
    renderKey.taoMap=mapKey;
    let h="";
    for(const m of GX.TAO_MAP){
      const on=m.id<=S.taoMax,en=taoEnemy(m.id);
      h+=`<div class="tao-node ${on?"":"lock"}">
        <div class="tao-ico">${m.icon}</div>
        <div class="tao-bd">
          <div class="tao-nm">${m.name}</div>
          <div class="tao-beast">${on?en.icon+" "+en.name+" · 气血 "+fmt(en.hp)+" · 攻击 "+fmt(en.atk):"雾气未散，尚未现世"}</div>
          ${on?`<div class="tao-btnrow"><button class="btn-xs" data-tao="${m.id}">出 战</button></div>`:""}
        </div>
      </div>`;
    }
    $("taoMapBox").innerHTML=h;
  }
  const mbox=$("taoMapBox");
  for(let i=1;i<=5;i++){
    const b=mbox.querySelector(`[data-tao="${i}"]`);
    if(b)b.disabled=!!B||S.taoCd>0||S.med>0;
  }
  // 战斗行动格（开战/结束/境界变化才重建）
  const actKey=B?B.node+"|"+S.realmIdx:"";
  if(actKey!==renderKey.taoAct){
    renderKey.taoAct=actKey;
    const box=$("taoActBox");
    if(!B){
      box.innerHTML=`<div class="tao-empty">择一处现世之妖，出手讨伐。<small>气血独立于寿元 · 败退重伤 15 秒、修为 -5% · 奖励随境界抬升 · 战毕冷却 30 秒</small></div>`;
    }else{
      box.innerHTML=`
      <div class="tao-bars">
        <div class="tao-side">
          <div class="tao-hp-l">你 · 气血 <b data-pv></b></div>
          <div class="bar"><i id="taoBarP"></i></div>
        </div>
        <div class="tao-vs" data-turnv></div>
        <div class="tao-side">
          <div class="tao-hp-l">${B.e.icon} ${B.e.name} <b data-epv></b></div>
          <div class="bar foe"><i id="taoBarE"></i></div>
        </div>
      </div>
      <div class="tao-acts">
        <button class="btn-sm" data-taob="strike">出 手</button>
        <button class="btn-sm" data-taob="treasure">法宝 2×<span data-pn="tr"></span></button>
        <button class="btn-sm" data-taob="beast">灵兽 1.5×<span data-pn="bs"></span></button>
        <button class="btn-sm" data-taob="pill_juli">聚灵丹 4×<span data-pn="juli"></span></button>
        <button class="btn-sm" data-taob="pill_xuan">玄丹 · 五回合攻+30%<span data-pn="xuan"></span></button>
        <button class="btn-sm" data-taob="pill_dujie">渡劫丹 · 五回合护+25%<span data-pn="dujie"></span></button>
        <button class="btn-sm" data-taob="pill_huichun">回春丹 · 气血+50%<span data-pn="huichun"></span></button>
        <button class="btn-sm" data-taob="guard">守 御 · 下次受创-60%</button>
        <button class="btn-sm" id="btnTaoToggle"></button>
        <button class="btn-sm" id="btnTaoFlee">撤 退</button>
      </div>`;
    }
  }
  const box=$("taoActBox");
  if(B){
    const bp=$("taoBarP"),be=$("taoBarE");
    if(bp)bp.style.width=(B.pPh/B.pMax*100)+"%";
    if(be)be.style.width=(B.eHp/B.eMax*100)+"%";
    const pv=box.querySelector("[data-pv]");if(pv)pv.textContent=fmt(B.pPh)+"/"+fmt(B.pMax);
    const ev=box.querySelector("[data-epv]");if(ev)ev.textContent=fmt(B.eHp)+"/"+fmt(B.eMax);
    const tv=box.querySelector("[data-turnv]");if(tv)tv.textContent="回合 "+B.turn;
    const tg=$("btnTaoToggle");
    if(tg)tg.textContent=B.pAuto?"⚙ 自动作战中 · 切手动":"✋ 手动指挥中 · 切自动";
    const setD=(k,d)=>{const b=box.querySelector(`[data-taob="${k}"]`);if(b)b.disabled=d};
    setD("treasure",!S.treasure);
    setD("beast",beastStars()<=0);
    setD("pill_juli",S.pills.juli<=0);
    setD("pill_xuan",S.pills.xuan<=0);
    setD("pill_dujie",S.pills.dujie<=0);
    setD("pill_huichun",S.pills.huichun<=0);
    // 丹药/法宝/灵兽余量小注（textContent，不重建按钮）
    const pn=box.querySelector('[data-pn="tr"]');if(pn)pn.textContent=S.treasure?"":" 无";
    const pb=box.querySelector('[data-pn="bs"]');if(pb)pb.textContent=" "+beastStars()+"星";
    for(const k of ["juli","xuan","dujie","huichun"]){
      const s=box.querySelector('[data-pn="'+k+'"]');if(s)s.textContent=" ×"+S.pills[k];
    }
  }
  // 状态提示行
  const hint=$("taoHint");
  const hv=B?`⚔ ${GX.TAO_MAP[B.node-1].name} · ${B.e.name} 缠斗中`
    :S.taoCd>0?`讨伐冷却 ${fmtTime(S.taoCd)}`
    :`已现世 ${S.taoMax}/5 · 妖兽随你的境界刷新（练气→大罗）`;
  if(hint.textContent!==hv)hint.textContent=hv;
}

/* ---- 块：功法 / 徽章 / 转世 / 天数 / 潮汐背景（轻量，无 key） ---- */
function renderMisc(){
  const gcost=gongfaCost();
  const gmax=gongfaMaxLv(), gtier=GX.GONGFA_TIERS[S.gongfaLv-1].name;
  $("gongfaLv").textContent=`${gtier} · 第 ${S.gongfaLv} 重`+(S.gongfaLv>=gmax?`（本境已至${GX.GONGFA_TIERS[gmax-1].name}封顶）`:"");
  const gb=$("btnGongfa");
  gb.disabled=S.spirit<gcost||S.gongfaLv>=gmax;
  gb.textContent=S.gongfaLv>=gmax?`已至 ${GX.GONGFA_TIERS[gmax-1].name} 封顶`:S.gongfaLv>=gmax-1?`参悟（${fmt(gcost)}灵石 · 至${GX.GONGFA_TIERS[gmax-1].name}）`:`参悟（${fmt(gcost)}灵石 · 可至${GX.GONGFA_TIERS[S.gongfaLv].name}）`;
  // buff 徽章
  let bx="";
  bx+=`<span class="badge ${S.buffs.tide>0?"on buff":""}">灵气潮汐 ${S.buffs.tide>0?fmtTime(S.buffs.tide):"—"}</span>`;
  bx+=`<span class="badge ${S.buffs.shock>0?"on debuff":""}">重伤 ${S.buffs.shock>0?fmtTime(S.buffs.shock):"—"}</span>`;
  bx+=`<span class="badge ${S.times>0?"on":""}">转世 ×${S.times}</span>`;
  if(S._xuanActive)bx+=`<span class="badge on">玄丹护体</span>`;
  if(S.tribBless)bx+=`<span class="badge on">天劫庇佑 +12%</span>`;
  $("badgeBox").innerHTML=bx;
  // 转世
  const pg=prestigeGain();
  $("btnPrestige").innerHTML=S.times>=1?
    (isFinalRealm()&&isTopLayer()?`☯️ 弃道转世（道行 +${pg}，不如证道飞升）`:`☯️ 转世重修（道行 +${pg}，全产出 +${pg*3}%）`):
    `☯️ 转世（需至少一世的修行）`;
  $("btnPrestige").disabled=pg<=0;
  $("prestigeInfo").innerHTML=`当前道行 <b style="color:var(--gold2)">${S.prestige}</b> · 全产出 +${S.prestige*3}%<br>🍑 道果 <b style="color:var(--gold2)">${S.daoFruit}</b> · 图鉴 ${codexCount()}/${codexTotal()}`;
  // 游戏日计数
  $("dayCount").textContent="第 "+Math.floor(tickN/100+1)+" 天";
  // 潮汐/重伤状态（视觉）
  const root=document.documentElement;
  if(S.buffs.tide>0)root.style.background="radial-gradient(1200px 560px at 50% -10%,#1f3a33 0%,transparent 62%),radial-gradient(900px 500px at 88% 112%,#101b26 0%,transparent 60%),var(--bg)";
  else if(S.buffs.shock>0)root.style.background="radial-gradient(1200px 560px at 50% -10%,#33202a 0%,transparent 62%),radial-gradient(900px 500px at 88% 112%,#101b26 0%,transparent 60%),var(--bg)";
  else root.style.background="";
}

/* ---- 块：成就（达成集合变化才重建） ---- */
function renderAch(){
  const key=JSON.stringify(S.achieved);
  if(key!==renderKey.ach){
    renderKey.ach=key;
    let ah="";
    for(const a of GX.ACHIEVEMENTS){
      const on=!!S.achieved[a.id];
      ah+=`<span class="badge ${on?"on ach":""}" title="${a.name}：${a.desc}（${a.fx}）">${on?"✓ ":""}${a.name}</span>`;
    }
    $("achBox").innerHTML=ah;
  }
}

/* ---- 块：道果图鉴（点亮/道果变化才重建） ---- */
function renderCodex(){
  const cc=codexCount();
  const lf=lifeFruit();
  $("fruitLine").innerHTML=`🍑 道果 <b>${S.daoFruit}</b> · 轮回方结（元婴以上始凝，此生预估 +${lf}）　｜　图鉴 <b>${cc}/${codexTotal()}</b> 项 · 全产出 <span class="fx">+${Math.round(cc*0.5)}%</span>`;
  const key=JSON.stringify(S.seen)+S.daoFruit;
  if(key!==renderKey.codex){
    renderKey.codex=key;
    const tTypes=Object.keys(GX.TREASURE_TYPES);
    const groups=[
      {t:"灵 根",gk:"roots",items:Object.keys(GX.ROOTS).map(id=>({k:id,n:GX.ROOTS[id].icon+GX.ROOTS[id].name}))},
      {t:"法 宝",gk:"treasures",items:(function(){const a=[];for(const t of GX.TREASURES)for(const ty of tTypes)a.push({k:t.q+"_"+ty,n:t.name+GX.TREASURE_TYPES[ty].name});return a})()},
      {t:"灵 兽",gk:"beasts",items:Object.keys(GX.BEASTS).map(id=>({k:id,n:GX.BEASTS[id].name}))},
      {t:"奇 遇",gk:"encs",items:GX.ENCOUNTERS.map(e=>({k:e.id,n:e.title}))},
      {t:"讨伐妖",gk:"tao",items:GX.TAO_MAP.map(m=>({k:String(m.id),n:m.icon+m.beast}))},
    ];
    let ch="";
    for(const g of groups){
      const seen=S.seen[g.gk]||{};
      const lit=g.items.filter(x=>seen[x.k]).length;
      ch+=`<div class="codex-group"><div class="cg-t">${g.t}<span class="cg-c">${lit}/${g.items.length}</span></div><div class="cg-grid">`;
      for(const x of g.items){
        const on=!!seen[x.k];
        ch+=`<div class="cg-item ${on?"lit":""}">${on?"":`<span class="cg-ico">✦</span>`}${x.n}</div>`;
      }
      ch+="</div></div>";
    }
    $("codexBox").innerHTML=ch;
  }
}

/* ---- 总入口 ---- */
function render(){
  renderCore();
  renderPills();
  renderBld();
  renderForge();
  renderEgg();
  renderBattle();
  renderMisc();
  renderAch();
  renderCodex();
}
