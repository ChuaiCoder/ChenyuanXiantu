// 无头回归：整世模拟 + V2 新系统断言
const fs=require('fs');
const path=require('path');
function el(){return{style:{setProperty(){}},classList:{add(){},remove(){},toggle(){},contains(){return false}},children:[],
  innerHTML:'',textContent:'',disabled:false,hidden:false,dataset:{},
  appendChild(c){this.children.push(c)},removeChild(){},insertBefore(a){this.children.unshift(a)},
  remove(){},closest(){return el()},querySelector(){return el()},querySelectorAll(){return[]},addEventListener(){},
  getBoundingClientRect(){return{left:0,top:0,width:100,height:30}}}}
const store={};
Object.defineProperty(globalThis,'localStorage',{value:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},configurable:true});
global.document={getElementById(){return el()},createElement(){return el()},addEventListener(){},body:{appendChild(){}},documentElement:el(),head:{appendChild(){}},querySelector(){return el()},querySelectorAll(){return[]}};
global.window={addEventListener(){}};
global.confirm=()=>true;global.prompt=()=>null;global.alert=m=>console.log('ALERT:',m);
global.btoa=s=>Buffer.from(s).toString('base64');global.atob=s=>Buffer.from(s,'base64').toString();
global.matchMedia=()=>({matches:true});
global.innerWidth=1280;global.innerHeight=720;
global.requestAnimationFrame=()=>0; // 背景动画只跑一帧
const ctxStub={clearRect(){},createRadialGradient(){return{addColorStop(){}}},beginPath(){},arc(){},fill(){}};
globalThis.addEventListener=()=>{};
// canvas 桩
const realGetElement=document.getElementById;
document.getElementById=id=>{
  const e=el();
  if(id==='bg')e.getContext=()=>ctxStub;
  return e;
};

const order=['data.js','core.js','state.js','actions.js','battle.js','trib.js','meta.js','render.js','main.js'];
let code='';
for(const f of order)code+=fs.readFileSync(path.join(__dirname,'js',f),'utf8')+'\n';

const sim=`
let pass=0,fail=0;
function T(n,c,...d){c?pass++:fail++;console.log(n,c?'PASS':'FAIL',c?"":d.join(" "))}
// 开局界面（首世随机觉醒）：先验证机制，再入世
T('开局界面已开',beginOpen===true&&beginRerolls===3,'beginOpen=',beginOpen);
T('重抽道缘生效',beginPending!==null&&(function(){const p=beginPending;rerollBegin();return beginRerolls===2})(),'rerolls=',beginRerolls);
const seenBeforeBegin=S.seen, drawnRoot=beginPending;
T('重抽不点亮图鉴',codexCount()===0,'cc=',codexCount());
commitBegin();
T('入世落定灵根（图鉴待一世走完）',!beginOpen&&S.root===drawnRoot&&codexCount()===0,'root=',S.root,'cc=',codexCount());
T('初始有灵根',!!GX.ROOTS[S.root],'root=',S.root);
T('首世道行0',S.prestige===0&&S.times===0);

// 掉落：点 500 次，统计掉率
const s0=S.spirit,sh0=S.shards.fan,eg0=S.eggs.fan+S.eggs.ling+S.eggs.xuan+S.eggs.di;
for(let i=0;i<500;i++)doCultivate({target:el()});
T('点击500次后灵石增加',S.spirit>s0);
T('有残片掉落',S.shards.fan>sh0,'shards=',S.shards.fan);
T('有蛋掉落概率(500次大概率)',(S.eggs.fan+S.eggs.ling+S.eggs.xuan+S.eggs.di)>eg0,'eggs=',JSON.stringify(S.eggs));

// 炼器
S.spirit=99999;S.bld.forge=1;
S.shards.fan=5;
forgeTreasure(1);
T('炼器装备',S.treasure&&S.treasure.q===1,'treasure=',JSON.stringify(S.treasure));
const t0=S.treasure;
forgeTreasure(1);
T('重炼替换',S.treasure.q===1);

// 渡劫：满修为必成
const origRandom=Math.random;
Math.random=()=>0.1;
S.realmIdx=0;S.layer=0;S.cult=layerNeed();
doBreak();
T('渡劫成功(90%)',S.layer===1,'layer=',S.layer);
// 渡劫失败扣30%+重伤（清除法宝加成，保证 95% > 成功率）
Math.random=()=>0.95;
S.treasure=null;S.pills.dujie=0;S.root="jin";
S.cult=layerNeed();
doBreak();
T('渡劫失败(95%)',S.layer===1&&S.buffs.shock>=20,'shock=',S.buffs.shock);

// 渡劫丹加成
Math.random=()=>0.99;
S.pills.dujie=1;S.cult=layerNeed();
doBreak();
T('渡劫丹自动消耗',S.pills.dujie===0,'dujie=',S.pills.dujie);

// 灵根折扣
S.root='jin';
const cJin=bldCost('zhen');
S.root='tu';
const cTu=bldCost('zhen');
T('土灵根建设-15%',cTu<cJin,'jin=',cJin,'tu=',cTu);
S.root='huo';
T('火灵根丹价-30%',pillCost('juli')===14,'juli=',pillCost('juli'));
S.root='shui';
const capShui=lifeCap();
S.root='tu';
T('水灵根寿元+20%',capShui>lifeCap(),'shui=',capShui,'tu=',lifeCap());

// 奇遇
openEncounter();
T('奇遇面板打开',encounterOpen===true);
closeEncounter();
T('奇遇关闭',encounterOpen===false);
T('奇遇计数',S.encN>=1,'encN=',S.encN);

// 闭关
const c0=S.cult;
S.med=0;startMed();
T('闭关启动',S.med===120,'med=',S.med);
const c1=S.cult;
doCultivate({target:el()});
T('闭关禁修炼',S.cult===c1,'cult=',S.cult);
S.med=0.5;last=performance.now()-1000;tick();
T('闭关自动凝练',S.cult>c1,'gain=',(S.cult-c1).toFixed(1));
T('闭关到期出定',S.med===0,'med=',S.med);

// 孵化升星
S.eggs.xuan=1;S.beasts.xuan=0;
hatchEgg('xuan');
T('孵化+1星',S.beasts.xuan===1,'beasts=',JSON.stringify(S.beasts));
S.eggs.xuan=1;hatchEgg('xuan');
const m0=globalMult();
S.beasts.xuan=5;
T('灵兽升星加产出',globalMult()>m0,'mult=',(globalMult()/m0).toFixed(2));
S.beasts.xuan=0;

// 成就
S.achieved={};S.breaks=0;
S.clicks=1000;checkAchievements();
T('成就:勤修不辍',!!S.achieved.click_1000,'ach=',Object.keys(S.achieved).join(','));
const m1=globalMult();S.achieved={};
T('成就加产出',m1>globalMult(),'mult=',(m1/globalMult()).toFixed(2));

// 离线收益
S.spirit=0;S.cult=0;S.bld.zhen=10;S.bld.mine=5;
S.lastTs=Date.now()-3600*1000;
const off=offlineEarnings();
T('离线收益(1h)',off>3599&&off<3602&&S.cult>0,'off=',off,'cult=',S.cult.toFixed(0));
S.lastTs=Date.now();

// 道心（天音问道）
S.realmIdx=6;
openEncounter();closeEncounter();
S.daoHeart=0;
const mhA=globalMult();
S.daoHeart=20;
T('道心上限+30%',Math.abs(globalMult()/mhA-1.3)<0.01,'ratio=',(globalMult()/mhA).toFixed(3));
S.daoHeart=0;

// 天劫面板（渡劫期层劫）
S.realmIdx=8;S.layer=0;S.cult=layerNeed();S.med=0;
doBreak();
T('渡劫期开天劫面板',tribOpen===true&&tribOpts.length===3,'tribOpen=',tribOpen);
// 借道果必成（层数前进 + 道果 10→6：渡劫期引渡费5、突破不再发果）
const layerBeforeFruit=S.layer;
S.daoFruit=10;
T('引渡分级:渡劫期费5',tribFruitCost()===5,'cost=',tribFruitCost());
tribOpts[1].act();
T('借道果必成',S.daoFruit===5&&S.layer===layerBeforeFruit+1,'fruit=',S.daoFruit,'layer=',S.layer);
// 驭雷成功奖励（残片+2，道果已改为轮回才结）
Math.random=()=>0.1;
S.cult=layerNeed();
doBreak();
tribOpts[2].act();
T('驭雷成功奖励',S.layer===2&&S.shards.fan>=2,'layer=',S.layer,'fan=',S.shards.fan);
// 天道终劫：连败因果递减
Math.random=()=>0.99;
S.realmIdx=8;S.layer=8;S.cult=layerNeed();S.tribFails=0;
doBreak();
const tca=tribChance('layer');
tribOpts[0].act(); // 硬渡失败
T('终劫失败+1因果',S.tribFails===1,'tribFails=',S.tribFails);
const tcb=tribChance('layer');
T('终劫连败递减',tcb<tca,'a=',tca.toFixed(2),'b=',tcb.toFixed(2));
Math.random=origRandom;
S.tribFails=0;

// 图鉴点亮 + 道果
const fBefore=S.daoFruit;
S.seen={roots:{},treasures:{},beasts:{},encs:{}};
markSeen('roots','jin','金灵根');
markSeen('roots','jin','金灵根'); // 重复不叠加
T('图鉴点亮不送道果(纯货币)',S.daoFruit===fBefore&&codexCount()===1,'fruit=',S.daoFruit,'cc=',codexCount());

// 道果/图鉴跨转世保留（S.root='jin' 已点亮 → 本次转世不重复加，验证保留路径）
// 注意：reincarnate 现按 lifeFruit 结算道果 → 设境界为练气（道果未凝）使结算为 0
S.root='jin';S.realmIdx=0;S.layer=0;
const fruitKeep=S.daoFruit, seenKeep=S.seen;
reincarnate(5);
T('道果跨世保留',S.daoFruit===fruitKeep,'fruit=',S.daoFruit);
T('图鉴跨世保留',S.seen===seenKeep&&codexCount()===1,'cc=',codexCount());
// 一世走完点亮本世灵根：新根首次走完 → 图鉴+1（道果不再随图鉴送）
S.root='mu';S.realmIdx=0;S.layer=0;
const fB2=S.daoFruit;
reincarnate(5);
T('走完一世点亮灵根图鉴',S.daoFruit===fB2&&!!S.seen.roots.mu&&codexCount()===2,'fruit=',S.daoFruit,'cc=',codexCount());

// 转世商店（道果 = 纯货币，转世界面购买，入世生效）
openBegin('new');
T('商店随开局窗开启',beginOpen===true);
S.daoFruit=100;
const rf0=S.daoFruit;
buyShop('reroll');
T('道缘重抽-5入暂存',S.daoFruit===rf0-5&&S._pend.reroll===1,'fruit=',S.daoFruit,'pend=',JSON.stringify(S._pend));
buyShop('pills');
T('丹药包-8且限一次',S.daoFruit===rf0-13&&shopBought.pills===true,'fruit=',S.daoFruit);
buyShop('pills');
T('限领商品二购拒绝',S.daoFruit===rf0-13,'fruit=',S.daoFruit);
S.daoFruit=3;
buyShop('daoheart');
T('道果不足拒绝',S.daoFruit===3,'fruit=',S.daoFruit);
const dujieB=S.pills.dujie, dhB=S.daoHeart||0;
S.daoFruit=100;
buyShop('daoheart');buyShop('provision');
applyShopPurchases();
T('入世结算暂存',S.pills.dujie===dujieB+1&&(S.daoHeart||0)===dhB+5&&S._pend&&Object.keys(S._pend).length===0,'pend=',JSON.stringify(S._pend),'dh=',S.daoHeart);
closeBegin();
T('商店关闭',beginOpen===false);
// 新商品：天劫庇佑 / 先天法宝 / 先天之体
openBegin('new');
S.daoFruit=100;
buyShop('tribbless');
buyShop('dharma');
buyShop('constitution');
applyShopPurchases();
T('天劫庇佑交付',S.tribBless===true);
T('先天法宝灵品装备+词条',S.treasure&&S.treasure.q===2&&S.treasure.words&&Object.values(S.treasure.words).length===1,'treasure=',JSON.stringify(S.treasure));
T('先天之体觉醒',!!GX.CONSTITUTIONS.find(x=>x.id===S.constitution),'cons=',S.constitution);
S.treasure=null;S.pills.dujie=0;S._xuanActive=false;S.root='jin';S.constitution=null; // 清掉渡劫加成，避免 98% 上限截断
S.tribBless=true;
const tcA=tribChance('realm'); // 用境界劫 60% 基准，避免 90%+12% 撞 98% 上限
S.tribBless=false;
T('天劫庇佑渡劫+12%',Math.abs(tcA-tribChance('realm')-0.12)<1e-9,'a=',tcA,'b=',tribChance('realm'));
S.constitution='leiti';
const mLeiti=globalMult();
S.constitution=null;
T('雷淬之体产出+30%',Math.abs(mLeiti/globalMult()-1.3)<0.01,'ratio=',(mLeiti/globalMult()).toFixed(3));
S.constitution='danti';
const tDanti=tribChance('layer');
S.constitution=null;
T('万法之体渡劫+10%',tDanti>tribChance('layer'),'a=',tDanti,'b=',tribChance('layer'));
S.constitution='yangti';
const capY=lifeCap();
S.constitution=null;
T('阳寿之体寿元+25%',capY>lifeCap(),'a=',capY,'b=',lifeCap());
closeBegin();

// 转世二选一
const roots=rollRoots(2);
T('灵根二选一',roots.length===2&&roots[0]!==roots[1],'roots=',roots);

// 秘境挑战
beginOpen=false; // 清掉转世测试遗留的开局窗（tick 冻结）
S.realmIdx=0;S.layer=0;S.secretCd=0;S.med=0;
T('秘境冷却重置',S.secretCd===0);
openSecret();
T('秘境可开（面板）',secretOpen===true&&encounterOpen===true,'secretOpen=',secretOpen,'enc=',encounterOpen);
T('秘境冷却扣减',S.secretCd===GX.SECRET_CD,'cd=',S.secretCd);
// 走完 3 回合（每回合选第一个选项）
for(let i=0;i<3;i++){
  T('秘境第'+(i+1)+'回合选项',secretOpts.length>=3,'opts=',secretOpts.length);
  secretOpts[0].act();
}
T('秘境结算关闭',secretOpen===false&&encounterOpen===false,'secretOpen=',secretOpen);
T('秘境冷却生效',S.secretCd===GX.SECRET_CD,'cd=',S.secretCd);
S.secretCd=GX.SECRET_CD;
const cd0=S.secretCd;
S.realmIdx=8;
for(let i=0;i<10;i++)tick();
T('秘境冷却按tick递减',S.secretCd<cd0,'cd=',S.secretCd);
S.realmIdx=0;

// 法宝祭炼
S.bld.mine=10;S.bld.forge=1;
S.shards.fan=999;S.spirit=999999;
S.treasure=null; // 清掉商店段预铭词条，保证新器无词
forgeTreasure(1);
T('新法宝无词条',S.treasure.words&&Object.keys(S.treasure.words).length===0,'words=',JSON.stringify(S.treasure.words));
const mW0=globalMult();
refineTreasure();
T('祭炼加词条',wordLevel('huxi')+wordLevel('juling')+wordLevel('yuan')===1,'words=',JSON.stringify(S.treasure.words));
T('祭炼耗灵石',S.spirit<999999);
// 聚灵诀词条提升全产出（固定词条后比较）
S.treasure.words={juling:3};
const mW1=globalMult();
T('聚灵诀词条加产出',mW1>mW0,'ratio=',(mW1/mW0).toFixed(3));
// 重炼继承：词条 30% 概率保留（多次统计，至少一次成功即合法）
let inheritHit=0;
for(let i=0;i<60;i++){
  S.treasure.words={juling:3}; // 每轮给旧器刻上词条再重炼（新器空词时旧词无源可承）
  forgeTreasure(1);
  if(wordLevel('juling')>0)inheritHit++;
}
T('重炼词条继承(60轮各30%期望18次)',inheritHit>=5,'hit=',inheritHit);
// 词条满级拒绝
S.treasure.words={huxi:3,juling:3,yuan:3};
refineTreasure();
T('词条满级拒绝',Object.values(S.treasure.words).every(v=>v===3),'words=',JSON.stringify(S.treasure.words));
S.treasure.words={juling:1};

// 仙界（飞升后四境 + 仙劫面板 + 证道飞升终局）
Math.random=origRandom;
// 道果轮回结算（突破不再发果，只在轮回时按此生修为结；元婴以下未凝；证道圆满加赠）
S.realmIdx=2;S.layer=9;
T('道果元婴以下未凝',lifeFruit()===0,'f=',lifeFruit());
S.realmIdx=3;S.layer=0;
T('道果元婴始凝(3)',lifeFruit()===3,'f=',lifeFruit());
S.realmIdx=8;S.layer=9;
T('道果渡劫圆满世(21)',lifeFruit()===21,'f=',lifeFruit());
S.realmIdx=12;S.layer=9;
T('道果证道圆满世(48含加赠)',lifeFruit()===48,'f=',lifeFruit());
S.realmIdx=8;S.layer=9;S.cult=layerNeed();S.med=0;S.daoFruit=0;
doBreak(); // 渡劫圆满 → 飞升（不再终局，也不再即时发果）
T('飞升踏入真仙(非终局)',S.realmIdx===9&&S.layer===0&&ended===false&&S.daoFruit===0,'ri=',S.realmIdx,'ended=',ended,'fruit=',S.daoFruit);
// 真仙 L0/L1 普通层劫（固定必成）→ L2 弹仙劫面板（天门劫）
Math.random=()=>0.1;
for(let i=0;i<2;i++){S.cult=layerNeed();doBreak()}
S.cult=layerNeed();
doBreak(); // 第 3 次：L2 命中仙劫层 → 开面板（层数未动）
T('真仙L2开仙劫面板',S.layer===2&&tribOpen===true&&tribOpts.length===3,'layer=',S.layer,'tribOpen=',tribOpen);
T('仙劫当前劫=天门劫',currentTri().tri.name==='天门劫','tri=',currentTri().tri.name);
S.daoFruit=10;
tribOpts[1].act(); // 借道果必成（真仙引渡费10，fruit 10→0；突破不再返还）
T('仙劫借道果必成',S.layer===3&&S.daoFruit===0,'layer=',S.layer,'fruit=',S.daoFruit);
// 真仙顶层（L9 圆满）→ 境界劫（非面板）
Math.random=()=>0.1;
S.layer=9;S.cult=layerNeed();
doBreak();
T('真仙顶层引动境界劫',tribOpen===false&&S.realmIdx===10&&S.layer===0,'ri=',S.realmIdx,'tribOpen=',tribOpen);
// 玄仙 L8 = 玄仙大劫：连败累因果
Math.random=()=>0.99;
S.realmIdx=10;S.layer=8;S.cult=layerNeed();S.tribFails=0;
doBreak();
T('玄仙L8开大劫面板',tribOpen===true&&currentTri().final===true,'final=',currentTri().final);
tribOpts[0].act(); // 硬渡失败
T('玄仙大劫失败+1因果',S.tribFails===1,'fails=',S.tribFails);
Math.random=()=>0.1;
S.cult=layerNeed();doBreak();
tribOpts[1].act(); // 借道果必成 → L9
T('玄仙大劫借果必成',S.layer===9&&S.tribFails===0,'layer=',S.layer,'fails=',S.tribFails);
// 大罗圆满（realmIdx=12, layer=9）→ 证道飞升（真终局，不再即时发果）
S.realmIdx=12;S.layer=9;S.cult=layerNeed();
T('大罗圆满按钮=证道飞升',breakInfo().kind==='ascend','kind=',breakInfo().kind);
const fF=S.daoFruit;
doAscendFinal();
T('证道飞升=终局',ended===true&&S.daoFruit===fF,'ended=',ended,'fruit=',S.daoFruit);
// 轮回结道果：坐化/终局后 reincarnate 按 lifeFruit 结算（大罗圆满=48）
{
  const before=S.daoFruit, tBefore=S.times;
  reincarnate(0);
  T('轮回结道果(大罗圆满48)',S.daoFruit===before+48,'fruit=',S.daoFruit,'delta=',S.daoFruit-before);
  T('轮回后新世状态',S.times===tBefore+1&&S.realmIdx===0&&S.layer===0,'times=',S.times);
  beginOpen=false; // 关闭轮回窗口，避免冻结后续 tick
  S.bld.mine=10;   // freshState 清矿产，恢复供道坛测试
}
ended=false;S.tribFails=0;S.daoFruit=0;
// 功法品阶（境界解锁上限：下品→神品 7 级）
S.realmIdx=0;S.gongfaLv=1;S.spirit=999999;
T('练气功法上限1重(下品)',gongfaMaxLv()===1,'max=',gongfaMaxLv());
buyGongfa();
T('练气封顶拒绝参悟',S.gongfaLv===1,'lv=',S.gongfaLv);
S.realmIdx=1;
T('筑基解锁中品(上限2)',gongfaMaxLv()===2,'max=',gongfaMaxLv());
buyGongfa();
T('参悟至2重',S.gongfaLv===2,'lv=',S.gongfaLv);
buyGongfa();
T('上限拒绝参悟',S.gongfaLv===2,'lv=',S.gongfaLv);
S.realmIdx=9;
T('真仙功法上限6重',gongfaMaxLv()===6,'max=',gongfaMaxLv());
S.realmIdx=11;
T('金仙功法上限7重(神品)',gongfaMaxLv()===7,'max=',gongfaMaxLv());
// 老档迁移：gongfaLv 超 7 重收敛
S.gongfaLv=12;migrate(S);
T('迁移收敛功法超档',S.gongfaLv===7,'lv=',S.gongfaLv);
S.realmIdx=0;

// 道坛（灵石后期出口：燃烧灵石产修为）
S.life=1;S.realmIdx=0;S.med=0;S.buffs.shock=0; // 清掉飞升段抬高的寿元（否则 tick 直接坐化）
S.bld.altar=0;
T('道坛未建速率0',altarRate()===0,'r=',altarRate());
S.bld.altar=3;
T('道坛速率>0',altarRate()>0,'r=',altarRate());
const altS=S.spirit,altC=S.cult;
S.spirit=1e9;S.med=0;S.buffs.shock=0;last=performance.now()-1000;
const altBefore=altarRate();
tick();
T('道坛烧灵产修为',S.cult>altC&&S.spirit<altS+1e9,'cult=',(S.cult-altC).toFixed(0),'spirit=',(S.spirit-altS).toFixed(0));
T('道坛耗灵不超速率',S.spirit>=altS-10*altBefore,'spent=',(altS-S.spirit).toFixed(0));
// 闭关期间道坛不烧（精确期望：修为=阵产+闭关凝练、灵石=矿，无道坛项）
S.med=60;S.buffs.tide=0;S.buffs.shock=0;
const spMed=S.spirit,culMed=S.cult;
last=performance.now()-1000;tick();
{
  const close=(a,b)=>Math.abs(a-b)<=Math.max(1e-9,Math.abs(b)*1e-6); // 相对容差
  const expCul=zhenRate()*1+cultPerClick()*5; // dt=1，speed=1（道坛 0 项）
  const expSpir=mineRate()*1;
  T('闭关卡道坛',close(S.cult-culMed,expCul)&&close(S.spirit-spMed,expSpir),
    'dCult=',(S.cult-culMed).toExponential(3),'exp=',expCul.toExponential(3),'dSpir=',(S.spirit-spMed).toExponential(3),'exp=',expSpir.toExponential(3));
}
S.med=0;
// 残片品级阶梯 + 仙品法宝
S.shards={fan:0,ling:0,xuan:0,di:0};
T('残片分池',shardCost(1).key==='fan'&&shardCost(2).key==='ling'&&shardCost(3).key==='xuan'&&shardCost(4).key==='di','sc=',JSON.stringify([shardCost(1),shardCost(2),shardCost(3),shardCost(4)]));
S.bld.forge=4;S.shards.di=15;
forgeTreasure(4);
T('仙品法宝装备',S.treasure&&S.treasure.q===4,'tr=',JSON.stringify(S.treasure));
S.shards.di=0;
forgeTreasure(4);
T('地品不足拒炼',S.treasure.q===4&&S.shards.di===0);
// 仙品残片入图鉴（4_型）
markSeen('treasures','4_wu','仙品·护体');
T('仙品图鉴可点亮',!!S.seen.treasures['4_wu'],'seen=',Object.keys(S.seen.treasures).join(','));
// 引渡分级
S.realmIdx=8;
T('引渡费:渡劫期5',tribFruitCost()===5,'c=',tribFruitCost());
S.realmIdx=9;
T('引渡费:真仙10',tribFruitCost()===10,'c=',tribFruitCost());
S.realmIdx=12;
T('引渡费:大罗25',tribFruitCost()===25,'c=',tribFruitCost());
S.realmIdx=8;
// 仙界秘境场景（minRealm 过滤）
S.realmIdx=9;
const pool9=GX.SECRET_EVENTS.filter(e=>S.realmIdx>=e.minRealm);
T('真仙场景池含仙气',pool9.some(e=>e.id==='xianqi'),'pool=',pool9.map(e=>e.id).join(','));
const pool0=GX.SECRET_EVENTS.filter(e=>0>=e.minRealm);
T('人界场景池无星海',pool0.every(e=>e.minRealm===0),'pool=',pool0.map(e=>e.id).join(','));
S.realmIdx=12;
const pool12=GX.SECRET_EVENTS.filter(e=>S.realmIdx>=e.minRealm);
T('大罗场景池含星海',pool12.some(e=>e.id==='luohai'),'pool=',pool12.map(e=>e.id).join(','));
S.realmIdx=0;

// 讨伐战斗（自动流回合攻防）
beginOpen=false;
S.realmIdx=0;S.layer=0;S.med=0;S.taoCd=0;battle=null;
T('讨伐首世开节点1',S.taoMax===1,'taoMax=',S.taoMax);
taoStart(5);
T('未解锁节点不可出战',battle===null,'battle=',battle);
taoStart(1);
T('开战(气血池独立)',battle!==null&&battle.eHp>0&&battle.pPh===battle.pMax,'eHp=',battle&&battle.eHp);
const eHpB=battle.eHp,pPhB=battle.pPh,turnB=battle.turn;
taoAct('strike');
T('出手伤敌',battle.eHp<eHpB,'eHp=',battle.eHp,'was=',eHpB);
T('敌方反扑',battle.pPh<pPhB,'pPh=',battle.pPh);
T('回合计数',battle.turn>turnB,'turn=',battle.turn);
battle.pAuto=1;battle.acc=1.6;
const turnA=battle.turn;
taoAutoTick(1.7);
T('自动回合推进',battle.turn>turnA||battle===null,'from=',turnA,'to=',battle&&battle.turn);
taoFlee();
T('撤退清战斗+冷却30',battle===null&&S.taoCd===30,'cd=',S.taoCd);
S.taoCd=0;
taoStart(1);
battle.eHp=1;
const spB=S.spirit,cuB=S.cult,fanB=S.shards.fan;
taoAct('strike');
T('胜结算:灵石/修为/残片',S.spirit>spB&&S.cult>cuB&&S.shards.fan>fanB,'sp+',S.spirit-spB,'cu+',S.cult-cuB,'fan=',S.shards.fan);
T('胜推进下一节点',S.taoMax===2,'taoMax=',S.taoMax);
T('讨伐计数+冷却',S.taoKills>=1&&S.taoCd===30,'kills=',S.taoKills,'cd=',S.taoCd);
S.taoCd=0;
taoStart(2);
battle.pPh=1;
const cuL=S.cult;
taoAct('strike');
T('败:重伤15秒+修为-5%',S.buffs.shock>=15&&S.cult<cuL&&battle===null,'shock=',S.buffs.shock);
S.buffs.shock=0;
S.beasts.fan=1;S.beasts.ling=1;
T('灵兽星总数',beastStars()===2,'stars=',beastStars());
S.treasure={q:3,type:'wu',words:{}};
T('法宝护体减伤(25/2=12.5%)',Math.abs(taoDefPct()-0.125)<1e-9,'d=',taoDefPct());
S.treasure=null;S.beasts.fan=0;S.beasts.ling=0;
T('图鉴总项含讨伐妖(38)',codexTotal()===38,'tot=',codexTotal());
const e0=taoEnemy(1);
S.realmIdx=5;
const e5=taoEnemy(1);
T('讨伐兽随境界变强',e5.hp>e0.hp&&e5.atk>e0.atk,'hp0=',e0.hp,'hp5=',e5.hp);
S.realmIdx=0;
migrate(S);
T('迁移补讨伐字段',S.taoMax>=1&&S.taoKills>=0&&S.seen.tao&&typeof S.seen.tao==='object');

// 整世模拟（bot 全开）
Math.random=origRandom;
S=freshState();S.root='lei';S.prestige=10;S.times=1;S.life=1;
let clicks=0;
for(let sec=0;sec<60*60*24*3&&!ended;sec++){
  for(let i=0;i<5;i++){doCultivate({target:el()});clicks++}
  for(const b of GX.BLDS){const cost=bldCost(b.id);if(S.spirit>=cost)buyBld(b.id)}
  for(const k in GX.PILLS){if(S.pills[k]<3&&S.spirit>=pillCost(k))craftPill(k)}
  {const sc=shardCost(1);if(S.shards[sc.key]>=sc.n&&S.bld.forge>=1&&Math.random()<0.3)forgeTreasure(1)}
  if(S.pills.dujie>0||true){}
  if(S.pills.huichun>0&&S.life/lifeCap()<0.8)usePill('huichun');
  if(S.pills.xuan>0)usePill('xuan');
  if(S.pills.juli>0)usePill('juli');
  if(S.eggs.fan>0&&Math.random()<0.1)releaseEgg('fan');
  if(!pending.herb)startHerb();
  if(!pending.roam&&S.life/lifeCap()>0.5)startRoam();
  if(breakInfo().ok)doBreak();
  if(tribOpen&&tribOpts[0]){ // 渡劫期：bot 有 10 道果走引渡（必成），否则硬渡
    const o=(S.daoFruit>=10&&tribOpts[1]&&!tribOpts[1].disabled)?tribOpts[1]:tribOpts[0];
    o.act();
  }
  if(secretOpen&&secretOpts.length)secretOpts[0].act(); // 秘境：选第一个选项走流程
  else if(encounterOpen)closeEncounter();
  if(S.secretCd<=0&&S.spirit>layerNeed()*2&&Math.random()<0.01)openSecret(); // 偶尔探秘境（吸灵石）
  if(!battle&&S.taoCd<=0&&S.med===0&&Math.random()<0.01)taoStart(Math.min(5,S.taoMax)); // 偶尔讨伐（自动流）
  last=performance.now()-1000;
  for(let t=0;t<3;t++)tick();
  if(S.cult>=layerNeed())doBreak();
}
console.log('整世: realm='+GX.REALMS[S.realmIdx].name+S.layer,'life='+S.life.toFixed(1)+'/'+lifeCap(),'ended='+ended,'clicks='+clicks);
T('整世可推进到筑基以上',S.realmIdx>=1||S.layer>=3);
T('整世结束方式合法',ended===true||S.realmIdx>0);
console.log('PASS',pass,'FAIL',fail);
process.exit(fail?1:0);
`;
eval(code+sim);
