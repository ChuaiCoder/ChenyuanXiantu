const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 860 } });
  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2500);

  await page.screenshot({ path: 'output/playwright/theme-ink.png' });

  // 修炼：金光 + 飘字
  await page.click('button.primary');
  await page.waitForTimeout(320);
  await page.screenshot({ path: 'output/playwright/fx-cultivate.png' });

  // 主题二：青云玉竹
  await page.click('.theme-dots .theme-dot:nth-child(2)');
  await page.waitForTimeout(900);
  await page.screenshot({ path: 'output/playwright/theme-jade.png' });

  // 主题三：血海魔修
  await page.click('.theme-dots .theme-dot:nth-child(3)');
  await page.waitForTimeout(900);
  await page.screenshot({ path: 'output/playwright/theme-blood.png' });

  // 回到默认主题，道途页楹联
  await page.click('.theme-dots .theme-dot:nth-child(1)');
  await page.click('.tabbar .tab:nth-child(5)');
  await page.waitForTimeout(700);
  await page.screenshot({ path: 'output/playwright/path-couplet.png' });

  await browser.close();
  console.log('screenshots done');
})().catch(e => { console.error(e); process.exit(1); });
