/* 卡点调试：从炼虚0层起跑，周期性打印状态 */
import { Engine } from '../server/engine.mjs';
import { GX, fmt } from '../shared/data.js';
import * as st from '../shared/state.js';
import { prepareProgression, chooseProgression } from './progression-bot.mjs';

const H = 3600;
const RIDX = parseInt(process.argv[2] || '5', 10);
const RAMP = parseFloat(process.argv[3] || '3000');
const orig = GX.REALM_NEED[RIDX];
GX.REALM_NEED[RIDX] = orig * RAMP;

const E = new Engine();
E.S = st.freshState();
E.S.root = 'jin';
E.S.realmIdx = RIDX; E.S.layer = 0; E.S.life = st.lifeCap(E.S);
E.S.gongfaLv = st.gongfaMaxLv(E.S); E.S.bld = { zhen: 30, mine: 30, beast: 8, furn: 3, forge: 3, altar: 5 };
E.closeBegin(); E.beginOpen = false; E.panel = null;

const NO_TAO = !!process.env.NO_TAO, NO_ENC = !!process.env.NO_ENC, NO_SEC = !!process.env.NO_SEC;

let sec = 0;
while (sec < 200 * H && !E.ended && E.S.realmIdx === RIDX) {
  prepareProgression(E); chooseProgression(E);
  if (!E.panel && !E.battle) {
    if (E.S.med <= 0 && E.S.medCd <= 0) E.startMed();
    if (E.S.med <= 0) { E.doCultivate(); E.doCultivate(); }
  }
  if (!E.panel) {
    for (const b of GX.BLDS) if (E.S.spirit >= st.bldCost(E.S, b.id)) E.buyBld(b.id);
    if (E.S.spirit >= st.gongfaCost(E.S)) E.buyGongfa();
    for (const k in GX.PILLS) if (!GX.PILLS[k].breakthrough && E.S.pills[k] < (k === 'huichun' ? 6 : 3) && E.S.spirit >= st.pillCost(E.S, k)) E.craftPill(k);
    if (E.S.pills.juli > 0) E.usePill('juli');
    if (E.S.pills.huichun > 0 && E.S.life < st.lifeCap(E.S) * 0.6) E.usePill('huichun');
    if (E.S.pills.yanshou > 0) E.usePill('yanshou');
    if (E.S.pills.xuan > 0 && !E.S._xuanActive) E.usePill('xuan');
    if (NO_SEC) E.S.secretCd = 999999; else if (E.S.secretCd <= 0) E.openSecret();
    if (!NO_TAO && E.S.taoCd <= 0 && E.S.med <= 0) E.taoStart(Math.min(E.S.taoMax, 3));
  }
  if (E.panel) {
    const p = E.panel;
    if (p.kind === 'trib') { const o = p.data.opts.find(x => x.id === 'fruit' && !x.disabled) || p.data.opts[0]; E.applyTribOption(o.id); }
    else if (p.kind === 'secret') E.applySecretOption(p.data.opts[0].id);
    else if (p.kind === 'encounter') E.applyEncOption(p.data.opts[0].id);
    else if (p.kind === 'gongfa') E.applyGongfaOption(p.data.opts[0].id);
  }
  if (E.battle) E.taoAutoTick(1);
  if (E.breakInfo().ok && !E.panel) E.doBreak();
  const cBefore = E.S.cult;
  E.tick(1); sec++;
  if (E.S.cult < cBefore * 0.97) {
    const recent = E.logs.slice(-3).map(l => l.text.replace(/<[^>]+>/g, '')).join(' | ');
    console.log(`  [暴跌 ${(sec / H).toFixed(1)}h] ${fmt(cBefore)} → ${fmt(E.S.cult)} :: ${recent}`);
  }
  if (sec % (20 * H) === 0)
    console.log(`${(sec / H).toFixed(0)}h layer=${E.S.layer} cult=${fmt(E.S.cult)}/${fmt(st.layerNeed(E.S))} 点击=${fmt(st.cultPerClick(E.S))} spirit=${fmt(E.S.spirit)} mine=${E.S.bld.mine} zhen=${E.S.bld.zhen} life=${E.S.life.toFixed(0)}/${st.lifeCap(E.S)} gongfa=${E.S.gongfaLv} panel=${E.panel ? E.panel.kind : '-'} battle=${!!E.battle} med=${E.S.med.toFixed(0)} medCd=${E.S.medCd.toFixed(0)}`);
}
console.log(`end: ${(sec / H).toFixed(1)}h realm=${E.S.realmIdx} layer=${E.S.layer} ended=${E.ended}`);
