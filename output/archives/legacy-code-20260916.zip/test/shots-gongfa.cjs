/* 功法三选一 UI 冒烟：参悟 → 面板 → 择一 → 书录墙 */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 860 } });
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));
  await p.goto('http://localhost:3000/', { waitUntil: 'networkidle' });
  await p.waitForTimeout(2500);
  // 点参悟
  await p.click('button:has-text("参悟")');
  await p.waitForTimeout(600);
  await p.screenshot({ path: 'output/playwright/gongfa-choice.png' });
  // 择第一部
  await p.click('.choice .enc-btn >> nth=0');
  await p.waitForTimeout(600);
  await p.screenshot({ path: 'output/playwright/gongfa-picked.png' });
  console.log('errors:', errs.length ? errs : 'none');
  await b.close();
})().catch(e => { console.error(e); process.exit(1); });
